# xork

`xork` is the short install name for [xorchestrate](https://pypi.org/project/xorchestrate/).

Once xorchestrate's first release is out, installing `xork` will install xorchestrate. Until then this package contains no code.

Source: https://github.com/xormania/xorchestrate
