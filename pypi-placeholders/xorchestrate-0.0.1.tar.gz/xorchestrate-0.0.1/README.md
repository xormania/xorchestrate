# xorchestrate

This name is reserved for **xorchestrate**, which runs agent harnesses through one shared, project-scoped MCP server.

The first real release is coming soon. Until then this package contains no code.

Source: https://github.com/xormania/xorchestrate
