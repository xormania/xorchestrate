import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
q=Path(__file__).parent;r=q/'restored';pub=q.parent/'review-publication/verification/pr6-independent-e565863';py=q.parent/'venv/bin/python'
with zipfile.ZipFile(pub/'Xorchestrate-PR6-Independent-e565863-Evidence.zip') as z:m=json.loads(z.read('package-manifest.json'))
for item in m['files']:
 p=r/item['path'];assert p.is_file() and p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
records=[]
commands=[('iv01',[py,r/'results/iv01/probe_assessment_binding_v2.py','--candidate',q/'candidate','--out',q/'iv01'],0),
 ('iv02',[py,r/'results/iv02/scripts/submission_gap_v2.py','--candidate',q/'candidate','--out',q/'iv02'],0),
 ('iv03',[py,r/'results/iv03/minimal_counterexamples.py','--candidate',q/'checker','--input',r/'results/execution/protocol','--out',q/'iv03'],1),
 ('iv04',[py,r/'inputs/original-witnesses/iv04.py','--candidate',q/'candidate','--out',q/'iv04'],0)]
for name,argv,expected in commands:
 start=time.time();result=subprocess.run(list(map(str,argv)),cwd=q/'candidate',env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(q/'candidate')},capture_output=True,timeout=300)
 (q/(name+'.stdout.log')).write_bytes(result.stdout);(q/(name+'.stderr.log')).write_bytes(result.stderr)
 records.append({'name':name,'command':list(map(str,argv)),'cwd':str(q/'candidate'),'expected_exit':expected,'exit':result.returncode,'elapsed_seconds':time.time()-start})
 (q/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==expected,(name,result.returncode)
iv01=json.loads((q/'iv01/results.json').read_text());assert len(iv01)==2 and all(x['defect_demonstrated'] and all(x['checks'].values()) for x in iv01)
iv02=json.loads((q/'iv02/summary.json').read_text());assert {x['peer']:x['raw_checker_veto'] for x in iv02['rows']}=={'codex':True,'grok':False};assert all(x['product_retains_pending'] and x['legitimate_completion'] for x in iv02['rows'])
iv03=json.loads((q/'iv03/summary.json').read_text());assert len(iv03['false_acceptances'])==15 and iv03['false_rejections']==[]
iv04=json.loads((q/'iv04/results.json').read_text())
identities={}
for name in ['candidate','checker']:
 root=q/name;identities[name]={'commit':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD^{tree}'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True)}
 assert identities[name]=={'commit':'e565863ae72180571678c8f6118ee6e00b129e2e','tree':'474de55c5947890ab4092daeca7ff39f9bbbc400','status':''}
summary={'archive_sha256':hashlib.sha256((pub/'Xorchestrate-PR6-Independent-e565863-Evidence.zip').read_bytes()).hexdigest(),'restored_files_independently_verified':len(m['files']),'identities':identities,'commands':records,'iv01':'disclosure_and_all_controls_reproduced','iv02':'accepted_interjection_gap_and_valid_controls_reproduced','iv03_false_acceptances':15,'iv04_results':iv04}
(q/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
