# Package QA passed

Primary archive SHA-256: `0ed0b6eccb4e15f381865e191b95e4b3e949431dd6c09989b2a38786a00200f0`.

The independent packaging check verified every ZIP CRC and all 5,352 payload hashes, sizes and manifest references, then restored and independently rehashed all 61,311 files in a fresh directory. File permissions and unchanged retained input identities also match.

All eight source-bundle refs were fetched explicitly into an empty repository. All 1,318 tracked source files match their Git blobs; recovered product `e565863ae72180571678c8f6118ee6e00b129e2e` has tree `474de55c5947890ab4092daeca7ff39f9bbbc400`. The retained hosted integration object has the same tree and includes this candidate as a parent.

With Python 3.12.14 and explicit `PYTHONPATH`, actual application/checker/observer imports resolve to that recovered checkout. Fresh IV01 adapted, IV03 original and IV04 original witnesses pass their denial, valid-control and attribution assertions. The source and all restored evidence remain unchanged afterward.

`run/report.json`, `run/command-ledger.json`, source hash proofs and the complete fresh witness outputs are retained. `qa-manifest.json` lists every QA archive member and explicit exclusions. Restored copies, Git recovery repositories/worktrees and caches are omitted because the primary archive and source bundle recover them.

This is same-session package/replay QA, not a repeat of the full suite, IV02 schedules, authenticated vendor acceptance or the later fresh-session independent review. The primary archive was not modified. No QA artifact refers to its own hash; the separately published checksum list binds this QA ZIP.
