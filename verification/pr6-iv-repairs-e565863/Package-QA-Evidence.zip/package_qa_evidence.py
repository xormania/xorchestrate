"""Package successful QA proofs without duplicating the restored primary tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).parent
    report = json.loads((args.run / 'report.json').read_text())
    assert report['status'] == 'passed' and all(report['checks'].values())
    files = [(name, root / name) for name in ('verify_package.py', 'package_qa_evidence.py', 'SUMMARY.md', 'qa-invocation.json')]
    excluded = []
    omitted = {'restored': 'Complete restored primary archive; independently verified then recoverable from primary',
               'replay/repository': 'Bundle recovery Git administration; recoverable from primary source bundle',
               'replay/candidate': 'Exact final worktree; file proof retained and recoverable from primary source bundle',
               'replay/baseline': 'Reviewed baseline worktree; recoverable from primary source bundle',
               'package-manifest.json': 'Exact primary manifest already in primary ZIP; SHA-256 retained in QA report'}
    skip_names = {'.git', '__pycache__', '.pytest_cache', '.ruff_cache'}
    for parent, directories, names in os.walk(args.run, followlinks=False):
        parent = Path(parent)
        for name in list(directories):
            item = parent / name
            relative = str(item.relative_to(args.run))
            if relative in omitted or name in skip_names or item.is_symlink():
                directories.remove(name)
                excluded.append({'path': 'run/' + relative, 'reason': omitted.get(relative, 'Git administration, cache or runtime directory alias')})
        for name in names:
            item = parent / name
            relative = str(item.relative_to(args.run))
            if relative in omitted or name in skip_names or name.endswith(('.pyc', '.pyo')):
                excluded.append({'path': 'run/' + relative, 'reason': omitted.get(relative, 'Git administration or bytecode cache')})
            elif item.is_symlink() or not item.is_file():
                excluded.append({'path': 'run/' + relative, 'reason': 'Runtime endpoint or symlink alias'})
            else:
                files.append(('run/' + relative, item))
    entries = [{'path': name, 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode),
                'sha256': sha(path)} for name, path in sorted(files)]
    manifest = {'schema': 'xorchestrate-package-qa-v1', 'primary_archive_sha256': report['archive_sha256'],
                'product_commit': report['candidate_expected'], 'product_tree': report['tree_expected'],
                'files': entries, 'excluded': excluded, 'scope': 'QA commands, hash/source proofs and fresh IV01/IV03/IV04 raw replays; restored copies are excluded explicitly.'}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(files):
            archive.write(path, name)
        archive.writestr('qa-manifest.json', json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    with zipfile.ZipFile(args.out) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {row['path'] for row in entries} | {'qa-manifest.json'}
        for entry in entries:
            data = archive.read(entry['path'])
            assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
    result = {'archive': str(args.out), 'sha256': sha(args.out), 'bytes': args.out.stat().st_size,
              'primary_archive_sha256': report['archive_sha256'], 'files': len(entries), 'status': 'passed'}
    (root / 'qa-archive.json').write_text(json.dumps(result, indent=2) + '\n')
    (root / 'qa-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
