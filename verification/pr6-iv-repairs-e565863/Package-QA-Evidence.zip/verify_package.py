"""Independent full package verification and source/witness replay.

Writes only beneath --out. Uses the supplied restorer and current interpreter,
with the recovered candidate explicitly selected for every source execution.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import traceback
import zipfile


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe_path(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and name and all(p not in ('', '.', '..') for p in name.split('/')), name
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--restorer', type=Path, required=True)
    parser.add_argument('--expected-sha256', required=True)
    parser.add_argument('--candidate', default='e565863ae72180571678c8f6118ee6e00b129e2e')
    parser.add_argument('--tree', default='474de55c5947890ab4092daeca7ff39f9bbbc400')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    args.out = args.out.resolve()
    args.out.mkdir(exist_ok=False)
    ledger, checks = [], {}
    report = {'status': 'running', 'checks': checks, 'archive': str(args.archive.resolve()),
              'python': sys.executable, 'python_version': sys.version,
              'candidate_expected': args.candidate, 'tree_expected': args.tree,
              'qa_script_sha256': sha_file(Path(__file__)), 'restorer_sha256': sha_file(args.restorer)}

    def save():
        (args.out / 'command-ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
        (args.out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

    def run(name, command, cwd=None, env=None):
        print(name, flush=True)
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
        finish = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (args.out / (name + '.stdout.log')).write_text(result.stdout)
        (args.out / (name + '.stderr.log')).write_text(result.stderr)
        ledger.append({'name': name, 'command': [str(x) for x in command], 'cwd': str(cwd) if cwd else None,
                       'environment_overrides': {k: env[k] for k in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE') if env and k in env},
                       'start_utc': start, 'end_utc': finish, 'exit_code': result.returncode})
        save()
        assert result.returncode == 0, (name, result.returncode, result.stderr[-2000:])
        return result.stdout

    def verify_restored(restored, files):
        expected = {entry['path'] for entry in files}
        actual = set()
        for parent, directories, names in os.walk(restored, followlinks=False):
            for name in list(directories):
                item = Path(parent) / name
                if item.is_symlink():
                    actual.add(str(item.relative_to(restored)))
                    directories.remove(name)
            actual.update(str((Path(parent) / name).relative_to(restored)) for name in names)
        assert actual == expected, {'missing': sorted(expected - actual)[:20], 'extra': sorted(actual - expected)[:20]}
        for entry in files:
            item = restored / entry['path']
            if entry['kind'] == 'symlink':
                assert item.is_symlink(), entry['path']
                data = os.fsencode(os.readlink(item))
                assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
            else:
                assert item.is_file() and not item.is_symlink(), entry['path']
                assert item.stat().st_size == entry['bytes'] and sha_file(item) == entry['sha256'], entry['path']
                assert stat.S_IMODE(item.stat().st_mode) == entry['mode'] & 0o777, entry['path']
        return len(files)

    try:
        print('archive CRC and complete independent payload audit', flush=True)
        report['archive_sha256'] = sha_file(args.archive)
        assert report['archive_sha256'] == args.expected_sha256
        checks['external_archive_sha256'] = True
        with zipfile.ZipFile(args.archive) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names))
            for name in names:
                safe_path(name)
            assert archive.testzip() is None
            checks['zip_crc_every_member'] = True
            manifest_raw = archive.read('package-manifest.json')
            report['package_manifest_sha256'] = hashlib.sha256(manifest_raw).hexdigest()
            manifest = json.loads(manifest_raw)
            assert manifest['schema'] == 'xorchestrate-independent-review-cas-v1'
            assert manifest['candidate'] == args.candidate and manifest['tree'] == args.tree
            checks['manifest_candidate_tree'] = True
            paths = [entry['path'] for entry in manifest['files']]
            assert len(paths) == len(set(paths))
            payloads = {}
            for entry in manifest['files']:
                safe_path(entry['path']); safe_path(entry['archive_path'])
                assert entry['kind'] in ('file', 'symlink')
                identity = (entry['sha256'], entry['bytes'])
                assert entry['archive_path'] not in payloads or payloads[entry['archive_path']] == identity
                payloads[entry['archive_path']] = identity
            assert set(names) == set(payloads) | {'package-manifest.json'}
            assert len(payloads) == manifest['unique_payloads']
            assert sum(entry['bytes'] for entry in manifest['files']) == manifest['original_bytes']
            for name, (expected_hash, expected_size) in payloads.items():
                h, size = hashlib.sha256(), 0
                with archive.open(name) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        h.update(block); size += len(block)
                assert h.hexdigest() == expected_hash and size == expected_size, name
            assert archive.read('restore_evidence.py') == args.restorer.read_bytes()
            checks['all_payload_hashes_sizes_and_references'] = True
            checks['supplied_restorer_matches_archive'] = True
            report['package'] = {'files': len(paths), 'unique_payloads': len(payloads),
                                 'original_bytes': manifest['original_bytes'], 'excluded': len(manifest['excluded'])}
            (args.out / 'package-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        run('restore-verify', [sys.executable, str(args.restorer.resolve()), str(args.archive.resolve()), '--verify-only'])
        restored = args.out / 'restored'
        run('restore-full', [sys.executable, str(args.restorer.resolve()), str(args.archive.resolve()), '--out', str(restored)])
        report['restored_files_independently_verified'] = verify_restored(restored, manifest['files'])
        checks['fresh_restore_all_files_hashes_modes'] = True
        identities = json.loads((restored / 'input-identities.json').read_text())
        assert identities['candidate'] == identities['checker_commit'] == args.candidate
        assert identities['tree'] == args.tree
        for name, identity in identities['files'].items():
            item = restored / name
            assert item.stat().st_size == identity['bytes'] and sha_file(item) == identity['sha256'], name
        checks['top_level_input_identity_claims_match_restored_files'] = True
        retained = json.loads((restored / 'inputs/retained-inputs.json').read_text())
        for entry in retained['files']:
            item = restored / 'inputs' / entry['path']
            assert item.stat().st_size == entry['bytes'] and sha_file(item) == entry['sha256']
        checks['unchanged_original_witnesses_and_protocol_inputs'] = True

        replay = args.out / 'replay'
        replay.mkdir()
        repository, candidate = replay / 'repository', replay / 'candidate'
        bundle = restored / 'evidence/root/repair-source.bundle'
        report['recovered_source_bundle_sha256'] = sha_file(bundle)
        run('git-init', ['git', 'init', str(repository)])
        run('bundle-verify', ['git', '-C', str(repository), 'bundle', 'verify', str(bundle)])
        heads = run('bundle-heads', ['git', 'bundle', 'list-heads', str(bundle)])
        run('bundle-fetch-explicit-refs', ['git', '-C', str(repository), 'fetch', str(bundle),
                                         'refs/repair-evidence/*:refs/repair-evidence/*'])
        refs = run('fetched-refs', ['git', '-C', str(repository), 'for-each-ref', '--format=%(objectname) %(refname)', 'refs/repair-evidence'])
        assert set(heads.splitlines()) == set(refs.splitlines())
        ref_map = {line.split(' ', 1)[1]: line.split(' ', 1)[0] for line in refs.splitlines()}
        assert ref_map == identities['source_bundle']['refs']
        checks['every_bundle_ref_fetched_explicitly'] = True
        hosted = identities['hosted']
        integration = run('hosted-integration-source-proof', ['git', '-C', str(repository), 'show', '-s',
                                                            '--format=%H%n%T%n%P', hosted['integration_commit']]).splitlines()
        assert integration[0] == hosted['integration_commit'] and integration[1] == args.tree == hosted['tree']
        assert integration[2].split() == hosted['parents'] and args.candidate in hosted['parents']
        checks['retained_hosted_integration_git_object_matches_final_tree'] = True
        run('worktree-final', ['git', '-C', str(repository), 'worktree', 'add', '--detach', str(candidate), 'refs/repair-evidence/final'])
        run('worktree-reviewed', ['git', '-C', str(repository), 'worktree', 'add', '--detach', str(replay / 'baseline'), 'refs/repair-evidence/reviewed'])
        identity = run('source-identity', ['git', '-C', str(candidate), 'show', '-s', '--format=%H%n%T%n%P']).splitlines()
        assert identity[0] == args.candidate and identity[1] == args.tree
        report['recovered_source_identity'] = identity
        source_entries = subprocess.check_output(['git', '-C', str(candidate), 'ls-tree', '-rz', 'HEAD']).split(b'\0')
        source_records = []
        for entry in filter(None, source_entries):
            info, raw_name = entry.split(b'\t', 1)
            mode, kind, blob = info.decode().split(' ')
            name = os.fsdecode(raw_name)
            assert kind == 'blob', (name, kind)
            item = candidate / name
            data = os.fsencode(os.readlink(item)) if mode == '120000' else item.read_bytes()
            actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            assert actual == blob, name
            if mode != '120000':
                assert bool(item.stat().st_mode & 0o111) == (mode == '100755'), name
            source_records.append({'path': name, 'git_blob': blob, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
        (args.out / 'recovered-source-files.json').write_text(json.dumps(source_records, indent=2) + '\n')
        checks['all_recovered_tree_files_match_git_blobs'] = True
        assert not run('source-clean-before', ['git', '-C', str(candidate), 'status', '--porcelain'])
        env = {**os.environ, 'PYTHONPATH': str(candidate), 'PYTHONDONTWRITEBYTECODE': '1'}
        origins_code = 'import json,xorchestrate.application,scripts.verification.checker,scripts.verification.pytest_calibration; print(json.dumps({m.__name__:m.__file__ for m in [xorchestrate.application,scripts.verification.checker,scripts.verification.pytest_calibration]}))'
        origins = json.loads(run('actual-module-origins', [sys.executable, '-c', origins_code], cwd=candidate, env=env))
        assert all(Path(path).resolve().is_relative_to(candidate) for path in origins.values())
        report['actual_module_origins'] = origins
        checks['explicit_restored_module_origins'] = True
        run('witness-iv01-adapted', [sys.executable, str(restored / 'evidence/iv01/closed-witness.py'),
                                   str(candidate), str(replay / 'iv01.json')], cwd=candidate, env=env)
        run('witness-iv03-original', [sys.executable, str(restored / 'inputs/original-witnesses/iv03.py'),
                                    '--candidate', str(candidate), '--baseline', str(restored / 'inputs/retained-ef-protocol'),
                                    '--out', str(replay / 'iv03')], cwd=candidate, env=env)
        run('witness-iv04-original', [sys.executable, str(restored / 'inputs/original-witnesses/iv04.py'),
                                    '--candidate', str(candidate), '--out', str(replay / 'iv04')], cwd=candidate, env=env)
        iv01 = json.loads((replay / 'iv01.json').read_text())
        assert {row['store'] for row in iv01} == {'memory', 'sqlite'}
        assert all(row['private_session_direct'] == 'denied' and row['authorized_public_session_preserved']
                   and not row['historical_get_work_contains_canary'] and not row['historical_get_delivery_contains_canary'] for row in iv01)
        checks['iv01_replay_controls_and_closed_invariant'] = True
        iv03 = json.loads((replay / 'iv03/results.json').read_text())
        assert len(iv03) == 4 and iv03[0]['name'] == 'control'
        assert iv03[0]['checker_status'] == 'passed' and iv03[0]['passed'] == 46 and iv03[0]['production_receipt']['verified'] is True
        assert all(row['checker_status'] == 'incomplete' and row['production_receipt']['verified'] is False for row in iv03[1:])
        checks['iv03_replay_control_and_contradictions'] = True
        iv04 = json.loads((replay / 'iv04/results.json').read_text())
        expected = {'same-line-raise': 'unrelated_failure', 'separate-line-raise': 'unrelated_failure', 'real-assertion': 'detected'}
        assert {row['name'] for row in iv04} == expected.keys()
        assert all(row['native'] == expected[row['name']] == row['work'] and row['control_exit'] == 0 and row['mutant_exit'] == 1 for row in iv04)
        checks['iv04_replay_both_calibrators_and_controls'] = True
        assert not run('source-clean-after', ['git', '-C', str(candidate), 'status', '--porcelain'])
        report['restored_files_unchanged_after_replay'] = verify_restored(restored, manifest['files'])
        checks['source_and_restored_evidence_unchanged'] = True
        report['status'] = 'passed'
    except Exception:
        report['status'] = 'failed'
        report['failure'] = traceback.format_exc()
        raise
    finally:
        save()
        print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
