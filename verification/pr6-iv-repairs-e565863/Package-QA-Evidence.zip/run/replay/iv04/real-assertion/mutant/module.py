def compute():
    return 2
def unrelated_environment_error():
    return None
