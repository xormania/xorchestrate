from module import compute, unrelated_environment_error
def test_target():
    observed = compute()
    assert observed == 1, "EXPECTED_VIOLATION"
    trouble = unrelated_environment_error()
    if trouble is not None:
        assert observed == 1, 'EXPECTED_VIOLATION'
        raise trouble
    assert observed == 1, "EXPECTED_VIOLATION"
def test_measurement_replay_is_bound_to_request_and_does_not_reexecute():
    assert True
