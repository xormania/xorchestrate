def compute():
    return 1
def unrelated_environment_error():
    return AssertionError('EXPECTED_VIOLATION')
