from pathlib import Path
import hashlib
import json
import tarfile
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
stage = base / 'evidence-stage'
data = stage / 'data'
source = base / 'xorchestrate/.xorchestrate/implementation-evidence/ci'
assert (source / 'final-ci.json').is_file()
provenance = json.loads((data / 'redaction-provenance.json').read_text())
files = {row['published_path']: row for row in provenance['files']}
def digest(content):
    return hashlib.sha256(content).hexdigest()
for file in [*source.rglob('*'), base / 'package_evidence.py', base / 'tool-versions.json', Path(__file__)]:
    if not file.is_file():
        continue
    relative = Path('development/ci') / file.relative_to(source) if source in file.parents else Path('publication') / file.name
    if file.name == 'tool-versions.json':
        relative = Path(file.name)
    content = file.read_bytes()
    target = data / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    files[str(relative)] = {'source': str(file), 'published_path': str(relative), 'original_sha256': digest(content),
        'derivative_sha256': digest(content), 'changed_json_paths': [], 'changes': 0}
provenance['files'] = list(files.values())
provenance['finalized_at'] = datetime.now(timezone.utc).isoformat()
(data / 'redaction-provenance.json').write_text(json.dumps(provenance, indent=2, sort_keys=True) + '\n')
index = {str(file.relative_to(data)): {'bytes': file.stat().st_size, 'sha256': digest(file.read_bytes())}
    for file in sorted(data.rglob('*')) if file.is_file()}
(stage / 'artifact-index.json').write_text(json.dumps(index, indent=2, sort_keys=True) + '\n')
with tarfile.open(stage / 'verification-evidence.tar.xz', 'w:xz') as archive:
    archive.add(data, arcname='evidence-data')
with tarfile.open(stage / 'verification-evidence.tar.xz') as archive:
    actual = {}
    for member in archive.getmembers():
        if member.isfile():
            relative = str(Path(member.name).relative_to('evidence-data'))
            content = archive.extractfile(member).read()
            actual[relative] = {'bytes': len(content), 'sha256': digest(content)}
    assert actual == index
print(json.dumps({'files_verified': len(index), 'archive_bytes': (stage / 'verification-evidence.tar.xz').stat().st_size,
    'archive_sha256': digest((stage / 'verification-evidence.tar.xz').read_bytes())}))
