"""Prepare reviewable, credential-redacted deterministic evidence derivatives."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import tarfile
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
REPO = BASE / 'xorchestrate'
FINAL = BASE / 'final-verification-3'
STAGE = BASE / (sys.argv[1] if len(sys.argv) > 1 else 'evidence-stage')
DATA = STAGE / 'data'
DATA.mkdir(parents=True, exist_ok=False)
provenance = []
omitted = []
tokens = {}


def sha(value):
    return hashlib.sha256(value).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def redact(value, path='', changes=None):
    if isinstance(value, dict):
        result = {}
        for key, child in value.items():
            subpath = path + '/' + key
            if key == 'resume_token' and isinstance(child, str):
                tokens.setdefault(child, 'REDACTED_BRIDGE_RESUME_TOKEN_' + str(len(tokens) + 1))
                result[key] = tokens[child]
                changes.append(subpath)
            else:
                result[key] = redact(child, subpath, changes)
        return result
    if isinstance(value, list):
        return [redact(child, path + '/' + str(i), changes) for i, child in enumerate(value)]
    return value


def copy(source, target):
    if not source.is_file():
        return
    content = source.read_bytes()
    changes = []
    if source.suffix == '.json':
        try:
            value = redact(json.loads(content), changes=changes)
            if changes:
                content = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
        except (ValueError, UnicodeDecodeError):
            pass
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    provenance.append({'source': str(source), 'published_path': str(target.relative_to(DATA)),
        'original_sha256': sha(source.read_bytes()), 'derivative_sha256': sha(content),
        'changed_json_paths': changes, 'changes': len(changes)})


def protocol(source, target):
    if not source.exists():
        return
    for file in sorted(source.rglob('*')):
        if not file.is_file():
            continue
        relative = file.relative_to(source)
        if ('peer-state' in relative.parts or file.name == 'host-state.json' or '.sqlite3' in file.name):
            omitted.append({'source': str(file), 'sha256': sha(file.read_bytes()),
                'reason': 'Private runtime credentials/state; complete JSON evidence exports retained'})
            continue
        copy(file, target / relative)


def calibration(source, target, work=False):
    for file in sorted(source.rglob('*')):
        if not file.is_file():
            continue
        parts = file.relative_to(source).parts
        if file.name.endswith('.tar.gz') or 'content' in parts or '__pycache__' in parts:
            continue
        if work and ('snapshot' in parts or 'candidate' in parts):
            continue
        if not work and ('control' in parts or 'mutant' in parts):
            continue
        copy(file, target / file.relative_to(source))


for file in (FINAL / 'commands').rglob('*'):
    copy(file, DATA / 'commands' / file.relative_to(FINAL / 'commands'))
for name in ['application.xml', 'run-summary.json', 'criteria.json']:
    copy(FINAL / name, DATA / name)
copy(FINAL / 'candidate/candidate.json', DATA / 'candidate.json')
copy(FINAL / 'candidate/working.patch', DATA / 'working.patch')
copy(BASE / 'tool-versions.json', DATA / 'tool-versions.json')
copy(Path(__file__), DATA / 'publication/package_evidence.py')
protocol(FINAL / 'protocol', DATA / 'protocol')
protocol(BASE / 'hosted-evidence/protocol', DATA / 'hosted-protocol')
for file in (BASE / 'hosted-evidence/tmux').rglob('*'):
    copy(file, DATA / 'hosted-tmux' / file.relative_to(BASE / 'hosted-evidence/tmux'))
calibration(FINAL / 'native-calibration', DATA / 'native-calibration')
calibration(FINAL / 'work-calibration', DATA / 'work-calibration', work=True)

for previous in ['final-verification', 'final-verification-2']:
    source, dest = BASE / previous, DATA / 'prior-runs' / previous
    for file in (source / 'commands').rglob('*'):
        copy(file, dest / 'commands' / file.relative_to(source / 'commands'))
    for name in ['application.xml', 'run-summary.json']:
        copy(source / name, dest / name)
    copy(source / 'candidate/candidate.json', dest / 'candidate.json')
    protocol(source / 'protocol', dest / 'protocol')
    copy(source / 'native-calibration/suite.json', dest / 'native-calibration.json')
    copy(source / 'work-calibration/calibration.json', dest / 'work-calibration.json')

components = REPO / '.xorchestrate/implementation-evidence'
for file in components.rglob('*'):
    if not file.is_file() or file.suffix not in {'.json', '.log', '.xml', '.md', '.txt', '.patch'}:
        continue
    relative = file.relative_to(components)
    if any(p in {'content', 'candidate', 'control', 'mutant', 'snapshot', '__pycache__', '.pytest_cache'}
           or p.endswith('-snapshot') for p in relative.parts):
        continue
    copy(file, DATA / 'development' / relative)

for previous in ['composed-protocol-1', 'composed-protocol-2', 'composed-protocol-3']:
    protocol(BASE / previous, DATA / 'prior-runs' / previous)

for extra in ['evidence-sessions-final', 'claude-wait-fix']:
    for file in (BASE / extra).rglob('*'):
        if file.is_file() and file.suffix in {'.json', '.log', '.xml', '.txt'}:
            copy(file, DATA / 'development' / extra / file.relative_to(BASE / extra))
for file in (BASE / 'component-source-recovery').rglob('*'):
    copy(file, DATA / 'component-source-recovery' / file.relative_to(BASE / 'component-source-recovery'))

# Known credential values must not survive in published bytes, even embedded text.
for file in DATA.rglob('*'):
    if file.is_file():
        content = file.read_bytes()
        assert not any(value.encode() in content for value in tokens), file
write(DATA / 'redaction-provenance.json', {'created_at': datetime.now(timezone.utc).isoformat(),
    'transformation': 'Stable per-token replacement only for runtime resume_token fields; credentials/state omitted',
    'files': provenance, 'omitted_files': omitted, 'native_evidence': 'none; deterministic protocol peers only'})

sys.path.insert(0, str(REPO))
from scripts.verification.checker import verify
def load(path):
    return json.loads(path.read_text())
p = DATA / 'protocol'
report = verify(load(p / 'run.json'), load(p / 'criteria.json'), load(p / 'bindings.json'), load(p / 'fixture.json'))
original = load(FINAL / 'protocol/report.json')
assert report == original and report['status'] == 'passed'
write(DATA / 'derivative-check.json', {'status': 'passed', 'report_identical': True, 'cases': len(report['cases']),
    'candidate': load(DATA / 'candidate.json')['commit'], 'checked_at': datetime.now(timezone.utc).isoformat()})
p = DATA / 'hosted-protocol'
hosted = verify(load(p / 'run.json'), load(p / 'criteria.json'), load(p / 'bindings.json'), load(p / 'fixture.json'))
assert hosted == load(BASE / 'hosted-evidence/protocol/report.json') and hosted['status'] == 'passed'
assert load(p / 'candidate.json')['content_sha256'] == load(DATA / 'candidate.json')['content_sha256']
write(DATA / 'hosted-derivative-check.json', {'status': 'passed', 'report_identical': True, 'cases': len(hosted['cases']),
    'same_candidate_content': True, 'checked_at': datetime.now(timezone.utc).isoformat()})
write(STAGE / 'artifact-index.json', {str(f.relative_to(DATA)): {'bytes': f.stat().st_size,
    'sha256': sha(f.read_bytes())} for f in sorted(DATA.rglob('*')) if f.is_file()})
with tarfile.open(STAGE / 'verification-evidence.tar.xz', 'w:xz') as archive:
    archive.add(DATA, arcname='evidence-data')
print(json.dumps({'files': len(provenance), 'redacted_files': sum(bool(f['changes']) for f in provenance),
    'omitted': len(omitted), 'archive_bytes': (STAGE / 'verification-evidence.tar.xz').stat().st_size,
    'archive_sha256': sha((STAGE / 'verification-evidence.tar.xz').read_bytes())}))
