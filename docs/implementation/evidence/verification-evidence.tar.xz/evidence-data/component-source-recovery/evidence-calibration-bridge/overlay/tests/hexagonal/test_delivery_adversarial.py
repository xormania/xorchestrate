"""Independent regressions for delivery/lifecycle authorization and stale effects."""
import itertools
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest

from xorchestrate.adapters.policies import ConfigurableRouting, RuleGuardrail
from xorchestrate.adapters.storage import MemoryStore
from xorchestrate.application import Application
from xorchestrate.composition import _wire_application_tools
from xorchestrate.model import Conflict, OrchestrationError


class Driver:
    def __init__(self):
        self.starts = []
        self.callback = None
        self.entered = threading.Event()
        self.release = threading.Event()
        self.send_error = None

    def start(self, specification):
        self.starts.append(specification)
        return {"native_id": "conversation", "incarnation": "generation-1", "handle": "connection"}

    def bind_application_tools(self, capabilities, callback):
        self.callback = callback

    def send(self, backend, message):
        self.entered.set()
        assert self.release.wait(2)
        if self.send_error:
            raise self.send_error
        return {"submitted": True}

    def stop(self, backend):
        return {"stopped": True}

    def detach(self, backend):
        return {"detached": True}

    def poll(self, backend):
        return []


def application(driver, *, guardrail=None, fallbacks=None, receipt_policy=None):
    identifiers = itertools.count(1)
    return Application(store=MemoryStore(), providers={}, sessions={"agent": driver},
        guardrail=guardrail or RuleGuardrail(), routing=ConfigurableRouting(), evaluators={},
        clock=lambda: "2026-10-23T12:00:00Z", identifiers=lambda: f"r{next(identifiers)}",
        session_fallbacks=fallbacks, receipt_policy=receipt_policy)


def start(app):
    return app.call("start_session", {"driver": "agent", "specification": {}, "idempotency_key": "start"})["session"]


def test_effective_fallback_driver_must_be_authorized_before_launch():
    driver = Driver()
    guardrail = RuleGuardrail({"rules": [{"actions": ["start_session"],
        "where": {"resolved_driver": "agent"}, "effect": "deny"}]})
    app = application(driver, guardrail=guardrail, fallbacks={"unavailable": "agent"})
    with pytest.raises(OrchestrationError) as rejected:
        app.call("start_session", {"driver": "unavailable", "specification": {}, "idempotency_key": "fallback"})
    assert rejected.value.code == "denied"
    assert driver.starts == [], "fallback_launch_authorized_as_effective_driver"


@pytest.mark.parametrize("closed_action", ["stop_session", "detach_session"])
def test_stale_native_callback_cannot_create_application_effect(closed_action):
    driver = Driver()
    app = application(driver)
    _wire_application_tools("agent", driver, app)
    session = start(app)
    app.call(closed_action, {"session_id": session["id"], "idempotency_key": "close"})
    context = {"actor": "owner", "session_id": session["id"], "native_id": "conversation",
               "incarnation": "generation-1", "call_id": "late-call"}
    with pytest.raises(OrchestrationError):
        driver.callback("create_work", {"goal": "A late stale callback"}, context, "late-call")
    assert app.call("list_work", {})["work"] == [], "stale_callback_did_not_create_work"


@pytest.mark.parametrize("closed_action,expected", [("stop_session", "stopped"), ("detach_session", "detached")])
@pytest.mark.parametrize("outcome", ["not_started", "unknown"])
def test_late_send_failure_never_reopens_closed_session(closed_action, expected, outcome):
    driver = Driver()
    driver.send_error = OrchestrationError("Late send result", "provider_unavailable", {"outcome": outcome})
    app = application(driver)
    session = start(app)
    with ThreadPoolExecutor(max_workers=1) as executor:
        sent = executor.submit(app.call, "send_session", {"session_id": session["id"],
            "message": {"text": "held"}, "idempotency_key": "send"})
        assert driver.entered.wait(1)
        app.call(closed_action, {"session_id": session["id"], "idempotency_key": "close"})
        driver.release.set()
        with pytest.raises(OrchestrationError):
            sent.result(timeout=1)
    current = app.call("list_sessions", {})["sessions"][0]
    assert current["status"] == expected, "late_send_failure_preserves_closed_lifecycle"
    with pytest.raises(OrchestrationError):
        app.call("send_session", {"session_id": session["id"], "message": {}, "idempotency_key": "after-close"})


def test_receipt_commit_rechecks_authorization_context_after_policy_evaluation():
    driver = Driver()
    app = None

    class Policy:
        def evaluate(self, snapshot, recipient, expectation):
            owner = next(item for item in app.call("list_actors", {})["actors"] if item["id"] == "owner")
            app.call("update_actor", {"actor_id": "owner", "expected_version": owner["version"],
                "changes": {"roles": ["revoked"]}})
            return {"verified": False, "diagnostics": ["deliberate test policy"]}

    guardrail = RuleGuardrail({"rules": [{"actions": ["verify_exchange"], "roles": ["revoked"], "effect": "deny"}]})
    app = application(driver, guardrail=guardrail, receipt_policy=Policy())
    app.call("add_actor", {"actor_id": "owner", "roles": ["allowed"]})
    app.call("add_actor", {"actor_id": "recipient"})
    message = app.call("send_message", {"destination": {"actor": "recipient"}, "body": {}})["message"]
    with pytest.raises(Conflict):
        app.call("verify_exchange", {"message_id": message["id"], "recipient": "recipient", "expectation": {}})
    assert app.call("get_delivery", {"message_id": message["id"]})["receipts"] == []


def test_callback_source_closed_during_authorization_cannot_commit_effect():
    driver = Driver()
    app = None
    source_id = None

    class Guardrail(RuleGuardrail):
        def evaluate(self, action, context):
            if action == "create_work" and context.get("native_source"):
                app.call("stop_session", {"session_id": source_id, "idempotency_key": "stop-during-authorization"})
            return super().evaluate(action, context)

    app = application(driver, guardrail=Guardrail())
    _wire_application_tools("agent", driver, app)
    source = start(app)
    source_id = source["id"]
    context = {"actor": "owner", "session_id": source_id, "native_id": "conversation",
               "incarnation": "generation-1", "call_id": "racing-call"}
    with pytest.raises(OrchestrationError):
        driver.callback("create_work", {"goal": "Concurrent callback"}, context, "racing-call")
    assert app.call("list_work", {})["work"] == [], "callback_binding_rechecked_at_commit"


def test_superseded_source_cannot_be_reactivated_by_late_send_result():
    driver = Driver()
    resume_entered = threading.Event()
    resume_release = threading.Event()

    def resume(backend, specification):
        resume_entered.set()
        assert resume_release.wait(2)
        return {"native_id": "conversation", "incarnation": "generation-2", "handle": "replacement"}

    driver.resume = resume
    app = application(driver)
    source = start(app)
    with ThreadPoolExecutor(max_workers=2) as executor:
        replacement = executor.submit(app.call, "start_session", {"driver": "agent", "specification": {},
            "resume_session_id": source["id"], "idempotency_key": "resume"})
        assert resume_entered.wait(1)
        sending = executor.submit(app.call, "send_session", {"session_id": source["id"],
            "message": {}, "idempotency_key": "old-send"})
        try:
            # Either source operations are fenced while replacing, or their late
            # completion must retain the superseded state after replacement.
            driver.entered.wait(.1)
            resume_release.set()
            replacement.result(timeout=1)
            driver.release.set()
            try:
                sending.result(timeout=1)
            except OrchestrationError:
                pass
        finally:
            resume_release.set()
            driver.release.set()
    sessions = {item["id"]: item for item in app.call("list_sessions", {})["sessions"]}
    assert sessions[source["id"]]["status"] == "superseded", "late_send_cannot_revive_superseded_source"


def test_delivery_selection_is_revalidated_before_native_effect():
    driver = Driver()
    driver.deliveries = []
    driver.deliver = lambda backend, envelope: driver.deliveries.append(envelope) or {"submitted": True}
    app = application(driver)
    app.call("add_actor", {"actor_id": "owner"})
    source = start(app)

    class Selection:
        def select(self, message, recipient, sessions):
            app.call("stop_session", {"session_id": source["id"], "idempotency_key": "stop-in-selection"})
            return source["id"]

    app.session_selection = Selection()
    message = app.call("send_message", {"destination": {"actor": "owner"}, "body": {"text": "after-close"}})["message"]
    app.call("dispatch_deliveries", {"message_id": message["id"]})
    assert driver.deliveries == [], "closed_selected_session_does_not_receive_native_delivery"
