"""Deterministic Claude protocol peer: real hook helper and MCP subprocess."""
import json
import os
import shlex
import signal
import subprocess
import sys
import threading
import uuid
from pathlib import Path


def argument(flag):
    return sys.argv[sys.argv.index(flag) + 1]


native_id = argument("--resume") if "--resume" in sys.argv else argument("--session-id")
settings = json.loads(Path(argument("--settings")).read_text())
config = json.loads(Path(argument("--mcp-config")).read_text())["mcpServers"]
server_name, mcp = next(iter(config.items()))
fault = os.environ.get("CLAUDE_FAULT", "")
state_dir = Path(os.environ["CLAUDE_STATE_DIR"])
state_dir.mkdir(parents=True, exist_ok=True)
state_file = state_dir / (native_id + ".json")
memory = json.loads(state_file.read_text()) if state_file.exists() else {}
write_lock = threading.Lock()
state_lock = threading.Lock()
pending = {}


def hook(event, **data):
    command = settings["hooks"][event][-1]["hooks"][0]["command"]
    packet = {"hook_event_name": event, "session_id": "wrong" if fault == "wrong_identity" else native_id, **data}
    result = subprocess.run(shlex.split(command), input=json.dumps(packet), capture_output=True, text=True, timeout=10)
    if result.returncode:
        raise RuntimeError("Hook rejected")
    return json.loads(result.stdout) if result.stdout.strip() else {}


hook("SessionStart", model="fixture-model")
proc = subprocess.Popen([mcp["command"], *mcp["args"]], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
                        env={**os.environ, "CLAUDE_CODE_SESSION_ID": native_id})


def write(packet):
    with write_lock:
        proc.stdin.write(json.dumps({"jsonrpc": "2.0", **packet}) + "\n")
        proc.stdin.flush()


def call(method, params):
    ident = uuid.uuid4().hex
    ready = threading.Event()
    with state_lock:
        pending[ident] = {"ready": ready}
    write({"id": ident, "method": method, "params": params})
    if not ready.wait(10):
        raise TimeoutError("MCP call timeout")
    with state_lock:
        response = pending.pop(ident)["response"]
    if "error" in response:
        raise RuntimeError("MCP call rejected")
    return response["result"]


def tool(name, arguments):
    if fault != "missing_tool_hook":
        hook("PreToolUse", tool_name=f"mcp__{server_name}__{name}", tool_input=arguments,
             tool_use_id=uuid.uuid4().hex, prompt_id="fixture-turn")
    return call("tools/call", {"name": name, "arguments": arguments})


def delivery(params):
    message = json.loads(params["content"])
    body = message.get("body", message)
    try:
        hook("UserPromptSubmit", prompt_id="fixture-turn")
        if "remember" in body:
            with state_lock:
                memory["marker"] = body["remember"]
                state_file.write_text(json.dumps(memory))
        if "recall" in body:
            tool("echo", {"marker": memory.get("marker"), "nonce": body["recall"]})
        if body.get("hold"):
            tool("hold", {"nonce": body["hold"]})
        if body.get("native_tool"):
            decision = hook("PreToolUse", tool_name=body["native_tool"], tool_input={"command": "fixture"},
                            tool_use_id=uuid.uuid4().hex)
            tool("echo", {"marker": "native_permission", "nonce": decision.get("hookSpecificOutput", {}).get("permissionDecision", "defer")})
        hook("Stop", prompt_id="fixture-turn")
    except Exception:
        hook("StopFailure", prompt_id="fixture-turn")


def read():
    for line in proc.stdout:
        packet = json.loads(line)
        if "id" in packet:
            with state_lock:
                entry = pending.get(packet["id"])
                if entry:
                    entry["response"] = packet
                    entry["ready"].set()
        elif packet.get("method") == "notifications/claude/channel":
            threading.Thread(target=delivery, args=(packet["params"],), daemon=True).start()


threading.Thread(target=read, daemon=True).start()
call("initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "fixture", "version": "1"}})
write({"method": "notifications/initialized", "params": {}})
if fault != "missing_registration":
    Path(argument("--debug-file")).write_text(f'2026-10-23T00:00:00.000Z [DEBUG] MCP server "{server_name}": Channel notifications registered\n')
while True:
    signal.pause()
