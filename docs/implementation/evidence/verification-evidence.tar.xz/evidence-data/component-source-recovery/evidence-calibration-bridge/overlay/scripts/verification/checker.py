"""Independent predicates adapted from multi-harness-proof a944f31b7527807d.

The exchange and native-call predicates preserve the PoC's complete round trip
and acknowledgement timing interpretation. Xorchestrate adds durable attempt,
application-session and incarnation bindings. No report-level success flag is an
input to a verdict. This checker must be selected/reviewed outside the candidate
when testing whether candidate changes preserved the owner requirements.
"""
from __future__ import annotations

from collections import Counter
import itertools
import json

from .capture import canonical, digest


PEERS = ("codex", "claude", "grok")
ORIGINS = {"codex": "codex/item/tool/call", "claude": "claude/PreToolUse",
           "grok": "grok/session/update"}


class VerificationFailure(Exception):
    def __init__(self, assertion):
        super().__init__(assertion)
        self.assertion = assertion


def require(value, assertion):
    if not value:
        raise VerificationFailure(assertion)


def native_inventory(peers=PEERS):
    """Requested coverage is declared before discovering or executing cases."""
    cases = [{"id": "startup-" + p, "kind": "startup", "peer": p} for p in peers]
    for source, target in itertools.permutations(peers, 2):
        cases.append({"id": f"direct-{source}-{target}", "kind": "exchange", "source": source, "target": target})
    for i, target in enumerate(peers):
        source = peers[(i + 1) % len(peers)]
        cases.append({"id": f"busy-{source}-{target}", "kind": "busy", "source": source, "target": target})
    for i, source in enumerate(peers):
        target = peers[(i + 1) % len(peers)]
        for burst in range(2):
            cases.append({"id": f"work-{source}-{target}-{burst}", "kind": "work_exchange",
                          "source": source, "target": target})
    for peer in peers:
        for batch in range(3):
            cases.append({"id": f"work-batch-{peer}-{batch}", "kind": "work", "peer": peer, "batch": batch})
        cases.append({"id": "completion-" + peer, "kind": "completion", "peer": peer})
        for operation in ("resume", "reconnect", "attach", "detach", "replace"):
            cases.append({"id": f"lifecycle-{peer}-{operation}", "kind": "lifecycle",
                          "peer": peer, "operation": operation})
    cases.append({"id": "native-tool-audit", "kind": "audit"})
    return cases


def default_criteria(brief_sha256):
    return {"version": 1, "owner_basis_sha256": brief_sha256,
            "requirements": [*(f"H{i}" for i in range(1, 9)), *(f"B{i}" for i in range(1, 6)), "A1", "A2"],
            "required_cases": native_inventory()}


def signature(event):
    return canonical({key: event.get(key) for key in
                      ("event", "tool", "arguments", "native_id", "incarnation", "session_id", "origin")})


def identity_matches(event, sessions):
    peer = event.get("peer")
    session = sessions.get(peer, {})
    return (event.get("native_id") and event.get("native_id") == session.get("native_id")
            and event.get("session_id") == session.get("session_id")
            and event.get("incarnation") and event.get("incarnation") == session.get("incarnation"))


def native_call(events, peer, tool, arguments, sessions, call_id=None):
    for event in events:
        if not (event.get("event") == "native_tool" and event.get("peer") == peer
                and event.get("tool") == tool and event.get("arguments") == arguments
                and event.get("call_id") and event.get("origin") == ORIGINS.get(peer)
                and identity_matches(event, sessions)
                and (call_id is None or event["call_id"] == call_id)):
            continue
        conflicts = [other for other in events
                     if other.get("event") in {"native_tool", "native_discovery"}
                     and other.get("peer") == peer and other.get("incarnation") == event["incarnation"]
                     and other.get("call_id") == event["call_id"] and signature(other) != signature(event)]
        if not conflicts:
            return event
    return None


def match_callback(events, event, sessions):
    native = native_call(events, event["peer"], event.get("tool"), event.get("arguments"),
                         sessions, event.get("call_id"))
    require(native, "native_call_missing_or_misbound")
    # The app side effect must be tied to this callback, not just have matching
    # free-form arguments somewhere in a transcript.
    require(event.get("call_id") == native["call_id"], "callback_call_binding")
    return native


def exchange_evidence(events, case, nonce, memory, sessions):
    case_id, source, target = case["id"], case["source"], case["target"]
    queued = [e for e in events if e.get("event") == "queued" and e.get("message", {}).get("case_id") == case_id]
    challenge = next((e for e in queued if e.get("peer") == source and
                      e["message"].get("to") == target and e["message"].get("kind") == "challenge"
                      and e["message"].get("nonce") == nonce and e["message"].get("memory") == ""), None)
    require(challenge, "challenge_missing_or_misbound")
    reply = next((e for e in queued if e.get("peer") == target and e["message"].get("to") == source
                  and e["message"].get("kind") == "reply" and e["message"].get("nonce") == nonce
                  and e["message"].get("memory") == memory), None)
    require(reply, "retained_context_reply_missing")
    receipt = next((e for e in events if e.get("event") == "report" and e.get("peer") == source
                    and e.get("report") == {"phase": "received", "case_id": case_id, "nonce": nonce,
                                            "memory": memory, "peer": target}), None)
    require(receipt, "sender_receipt_missing")
    require(challenge["seq"] < reply["seq"] < receipt["seq"], "exchange_event_order")
    submissions = []
    for message, recipient in ((challenge, target), (reply, source)):
        submitted = next((e for e in events if e.get("event") == "submitted" and e.get("peer") == recipient
                          and e.get("message_id") == message["message"]["id"] and e.get("attempt_id")
                          and e.get("state") == "submitted" and identity_matches(e, sessions)), None)
        require(submitted, "native_submission_missing_or_misbound")
        require(message["seq"] < submitted["seq"], "submission_before_message")
        attempt = next((e for e in events if e.get("event") == "attempt" and
                        all(e.get(k) == submitted.get(k) for k in
                            ("message_id", "attempt_id", "peer", "session_id", "incarnation"))), None)
        require(attempt, "delivery_attempt_missing_or_misbound")
        submissions.append(submitted)
    observed = [match_callback(events, event, sessions) for event in (challenge, reply, receipt)]
    timing = {"challenge_ack_after_reply": submissions[0]["seq"] > reply["seq"],
              "reply_ack_after_receipt": submissions[1]["seq"] > receipt["seq"]}
    if case["kind"] == "busy":
        started = next((e for e in events if e.get("event") == "hold_started" and
                        e.get("peer") == target and e.get("case_id") == case_id), None)
        finished = next((e for e in events if e.get("event") == "hold_finished" and
                         e.get("peer") == target and e.get("case_id") == case_id and e.get("released") is True), None)
        require(started and finished, "outstanding_tool_hold_missing")
        match_callback(events, started, sessions)
        require(started["seq"] < submissions[0]["seq"] < finished["seq"], "submission_outside_tool_hold")
        timing["reply_before_hold_finished"] = reply["seq"] < finished["seq"]
    if case["kind"] == "work_exchange":
        started = next((e for e in events if e.get("event") == "work_started" and e.get("peer") == target), None)
        finished = next((e for e in events if e.get("event") == "work_completed" and e.get("peer") == target), None)
        require(started and finished and started["seq"] < submissions[0]["seq"] < finished["seq"],
                "submission_outside_unfinished_work")
        timing["reply_before_work_completed"] = reply["seq"] < finished["seq"]
    return {"event_seqs": [challenge["seq"], submissions[0]["seq"], reply["seq"], submissions[1]["seq"], receipt["seq"]],
            "native_seqs": [e["seq"] for e in observed], "timing": timing,
            "attempt_ids": [e["attempt_id"] for e in submissions]}


def tool_audit(events, sessions):
    actual = [e for e in events if e.get("event") == "tool_called"]
    require(actual, "native_calls_not_exercised")
    unique_actual = set()
    for event in actual:
        key = (event.get("peer"), event.get("incarnation"), event.get("call_id"))
        require(key not in unique_actual, "duplicate_application_invocation")
        unique_actual.add(key)
        match_callback(events, event, sessions)
    for event in events:
        if event.get("event") in {"native_tool", "native_discovery", "native_session"}:
            require(identity_matches(event, sessions), "native_session_drift")
        require(event.get("event") not in {"native_identity_error", "tool_violation", "unsupported"},
                "native_protocol_violation")
    return {"audited_calls": len(actual)}


def expected_work(rows):
    latest = {}
    for row in rows:
        if row["job"] not in latest or row["attempt"] > latest[row["job"]]["attempt"]:
            latest[row["job"]] = row
    failures = [r for r in latest.values() if r["status"] == "FAIL"]
    return {"failed_jobs": sorted(r["job"] for r in failures),
            "failed_tests": sum(r["failed_tests"] for r in failures)}


def check_case(case, run, fixture):
    events, sessions = run["events"], run["sessions"]
    kind = case["kind"]
    if kind in {"exchange", "busy", "work_exchange"}:
        return exchange_evidence(events, case, run["nonces"][case["id"]], run["memories"][case["target"]], sessions)
    if kind == "audit":
        return tool_audit(events, sessions)
    peer = case["peer"]
    own = [e for e in events if e.get("peer") == peer]
    if kind == "startup":
        ready = next((e for e in own if e.get("event") == "report" and e.get("report") == {
            "phase": "ready", "case_id": "startup", "nonce": "", "memory": run["memories"][peer], "peer": ""}), None)
        require(ready, "private_marker_startup_missing")
        match_callback(events, ready, sessions)
        return {"event_seqs": [ready["seq"]]}
    if kind == "work":
        result = next((e for e in own if e.get("event") == "work_submitted" and e.get("batch") == case["batch"]), None)
        require(result, "work_batch_not_exercised")
        match_callback(events, result, sessions)
        require(result.get("answer") == expected_work(fixture["batches"][case["batch"]]), "incorrect_work")
        return {"event_seqs": [result["seq"]]}
    if kind == "completion":
        completion = [e for e in own if e.get("event") == "activity" and e.get("state") == "idle"
                      and e.get("basis") == "native" and identity_matches(e, sessions)]
        submitted = [e["seq"] for e in own if e.get("event") == "submitted"]
        require(completion and submitted and completion[-1]["seq"] > max(submitted), "native_completion_missing")
        return {"event_seqs": [completion[-1]["seq"]]}
    if kind == "lifecycle":
        lifecycle = next((e for e in own if e.get("event") == "lifecycle" and e.get("operation") == case["operation"]), None)
        require(lifecycle, "lifecycle_not_exercised")
        before, after = lifecycle.get("before", {}), lifecycle.get("after", {})
        require(before.get("native_id") and before.get("native_id") == after.get("native_id"), "lifecycle_native_identity")
        if case["operation"] == "detach":
            require(before.get("ownership") == "external" and lifecycle.get("process_alive_after") is True,
                    "external_process_terminated")
            require(after.get("connection") == "detached", "detach_connection_state")
        else:
            require(before.get("incarnation") != after.get("incarnation"), "lifecycle_incarnation_not_replaced")
            require(lifecycle.get("stale_rejected") is True, "stale_connection_accepted")
            retained = lifecycle.get("retained_observation")
            require(isinstance(retained, dict) and retained.get("memory") == run["memories"][peer], "lifecycle_context_lost")
            require(retained.get("native_id") == after.get("native_id") and
                    retained.get("incarnation") == after.get("incarnation") and retained.get("call_id"),
                    "lifecycle_retained_observation_binding")
        return {"event_seqs": [lifecycle["seq"]]}
    raise VerificationFailure("unsupported_required_case")


def verify(run, criteria, expected_bindings, fixture):
    """Compute coverage and predicates from evidence; ignore run['status']."""
    require(run.get("bindings") == expected_bindings, "measurement_binding_mismatch")
    require(expected_bindings.get("criteria_sha256") == digest(canonical(criteria)), "criteria_binding_mismatch")
    require(expected_bindings.get("fixture_sha256") == digest(canonical(fixture)), "fixture_binding_mismatch")
    requested = criteria["required_cases"]
    ids = [case["id"] for case in requested]
    require(len(ids) == len(set(ids)), "duplicate_required_case")
    seqs = [e.get("seq") for e in run.get("events", [])]
    require(all(type(seq) is int for seq in seqs) and seqs == sorted(set(seqs)), "event_sequence_integrity")
    executed = run.get("executed_cases", [])
    require(len(executed) == len(set(executed)), "duplicate_executed_case")
    results = []
    for case in requested:
        result = {"id": case["id"], "status": "not_exercised"}
        if case["id"] in executed:
            try:
                result.update(evidence=check_case(case, run, fixture), status="passed")
            except VerificationFailure as exc:
                result.update(status="failed", assertion=exc.assertion)
            except (KeyError, TypeError, IndexError, ValueError) as exc:
                result.update(status="invalid_evidence", error=type(exc).__name__)
        results.append(result)
    return {"status": "passed" if results and all(r["status"] == "passed" for r in results) else "incomplete",
            "mode": run.get("mode", "unknown"), "bindings": expected_bindings,
            "requested": ids, "discovered": run.get("discovered_cases", []), "executed": executed,
            "cases": results,
            "native_acceptance": "pending_local_run" if run.get("mode") != "native" else
                ("passed" if results and all(r["status"] == "passed" for r in results) else "incomplete")}
