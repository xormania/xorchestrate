"""Independent regressions for delivery/lifecycle authorization and stale effects."""
import itertools
import threading
from concurrent.futures import ThreadPoolExecutor

import pytest

from xorchestrate.adapters.policies import ConfigurableRouting, RuleGuardrail
from xorchestrate.adapters.storage import MemoryStore
from xorchestrate.application import Application
from xorchestrate.composition import _wire_application_tools
from xorchestrate.model import Conflict, OrchestrationError


class Driver:
    def __init__(self):
        self.starts = []
        self.callback = None
        self.entered = threading.Event()
        self.release = threading.Event()
        self.send_error = None

    def start(self, specification):
        self.starts.append(specification)
        return {"native_id": "conversation", "incarnation": "generation-1", "handle": "connection"}

    def bind_application_tools(self, capabilities, callback):
        self.callback = callback

    def send(self, backend, message):
        self.entered.set()
        assert self.release.wait(2)
        if self.send_error:
            raise self.send_error
        return {"submitted": True}

    def stop(self, backend):
        return {"stopped": True}

    def detach(self, backend):
        return {"detached": True}

    def poll(self, backend):
        return []


def application(driver, *, guardrail=None, fallbacks=None, receipt_policy=None):
    identifiers = itertools.count(1)
    return Application(store=MemoryStore(), providers={}, sessions={"agent": driver},
        guardrail=guardrail or RuleGuardrail(), routing=ConfigurableRouting(), evaluators={},
        clock=lambda: "2026-10-23T12:00:00Z", identifiers=lambda: f"r{next(identifiers)}",
        session_fallbacks=fallbacks, receipt_policy=receipt_policy)


def start(app):
    return app.call("start_session", {"driver": "agent", "specification": {}, "idempotency_key": "start"})["session"]


def test_effective_fallback_driver_must_be_authorized_before_launch():
    driver = Driver()
    guardrail = RuleGuardrail({"rules": [{"actions": ["start_session"],
        "where": {"resolved_driver": "agent"}, "effect": "deny"}]})
    app = application(driver, guardrail=guardrail, fallbacks={"unavailable": "agent"})
    with pytest.raises(OrchestrationError) as rejected:
        app.call("start_session", {"driver": "unavailable", "specification": {}, "idempotency_key": "fallback"})
    assert rejected.value.code == "denied"
    assert driver.starts == [], "fallback_launch_authorized_as_effective_driver"


@pytest.mark.parametrize("closed_action", ["stop_session", "detach_session"])
def test_stale_native_callback_cannot_create_application_effect(closed_action):
    driver = Driver()
    app = application(driver)
    _wire_application_tools("agent", driver, app)
    session = start(app)
    app.call(closed_action, {"session_id": session["id"], "idempotency_key": "close"})
    context = {"actor": "owner", "session_id": session["id"], "native_id": "conversation",
               "incarnation": "generation-1", "call_id": "late-call"}
    with pytest.raises(OrchestrationError):
        driver.callback("create_work", {"goal": "A late stale callback"}, context, "late-call")
    assert app.call("list_work", {})["work"] == [], "stale_callback_did_not_create_work"


@pytest.mark.parametrize("closed_action,expected", [("stop_session", "stopped"), ("detach_session", "detached")])
@pytest.mark.parametrize("outcome", ["not_started", "unknown"])
def test_late_send_failure_never_reopens_closed_session(closed_action, expected, outcome):
    driver = Driver()
    driver.send_error = OrchestrationError("Late send result", "provider_unavailable", {"outcome": outcome})
    app = application(driver)
    session = start(app)
    with ThreadPoolExecutor(max_workers=1) as executor:
        sent = executor.submit(app.call, "send_session", {"session_id": session["id"],
            "message": {"text": "held"}, "idempotency_key": "send"})
        assert driver.entered.wait(1)
        app.call(closed_action, {"session_id": session["id"], "idempotency_key": "close"})
        driver.release.set()
        with pytest.raises(OrchestrationError):
            sent.result(timeout=1)
    current = app.call("list_sessions", {})["sessions"][0]
    assert current["status"] == expected, "late_send_failure_preserves_closed_lifecycle"
    with pytest.raises(OrchestrationError):
        app.call("send_session", {"session_id": session["id"], "message": {}, "idempotency_key": "after-close"})


def test_receipt_commit_rechecks_authorization_context_after_policy_evaluation():
    driver = Driver()
    app = None

    class Policy:
        def evaluate(self, snapshot, recipient, expectation):
            owner = next(item for item in app.call("list_actors", {})["actors"] if item["id"] == "owner")
            app.call("update_actor", {"actor_id": "owner", "expected_version": owner["version"],
                "changes": {"roles": ["revoked"]}})
            return {"verified": False, "diagnostics": ["deliberate test policy"]}

    guardrail = RuleGuardrail({"rules": [{"actions": ["verify_exchange"], "roles": ["revoked"], "effect": "deny"}]})
    app = application(driver, guardrail=guardrail, receipt_policy=Policy())
    app.call("add_actor", {"actor_id": "owner", "roles": ["allowed"]})
    app.call("add_actor", {"actor_id": "recipient"})
    message = app.call("send_message", {"destination": {"actor": "recipient"}, "body": {}})["message"]
    with pytest.raises(Conflict):
        app.call("verify_exchange", {"message_id": message["id"], "recipient": "recipient", "expectation": {}})
    assert app.call("get_delivery", {"message_id": message["id"]})["receipts"] == []
