"""Independent protocol peer: acknowledges, then calls back while work is held.

A deterministic subprocess fixture, never authenticated native evidence.
"""
import json
import os
import subprocess
import sys
import threading
import time
import uuid

protocol = sys.argv[1]
write_lock = threading.Lock()
state_lock = threading.Lock()
native_id = 'native-' + uuid.uuid4().hex
callbacks = {}
responses = {}
mcp = None
counter = 0
params_start = {}


def write(packet):
    with write_lock:
        if protocol != 'codex':
            packet = {'jsonrpc': '2.0', **packet}
        print(json.dumps(packet), flush=True)


def call(name, args, prompt=None, observed=True):
    call_id = uuid.uuid4().hex
    if protocol == 'codex':
        event = threading.Event()
        callbacks[call_id] = event
        write({'id': call_id, 'method': 'item/tool/call', 'params': {
            'threadId': native_id, 'callId': call_id, 'tool': name, 'arguments': args}})
        assert event.wait(10), 'native callback did not complete'
        return responses[call_id].get('result')
    if observed:
        write({'method': 'session/update', 'params': {'sessionId': native_id, 'promptId': prompt,
            'update': {'sessionUpdate': 'tool_call', 'toolCallId': call_id, 'title': 'xorchestrate__' + name,
                       'rawInput': args, '_meta': {'x.ai/tool': {'version': 1, 'namespace': 'mcp', 'name': 'xorchestrate__' + name}}}}})
    return mcp.request('tools/call', {'name': name, 'arguments': args})


class MCP:
    def __init__(self, spec):
        self.process = subprocess.Popen([spec['command'], *spec['args']], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=sys.stderr, text=True)
        self.lock = threading.Lock()
        self.waiting = {}
        self.answers = {}
        self.seq = 0
        threading.Thread(target=self.read, daemon=True).start()
        self.request('initialize', {'protocolVersion': '2025-06-18', 'clientInfo': {'name': 'peer', 'version': '1'}, 'capabilities': {}})
        self.notify('notifications/initialized', {})

    def read(self):
        for line in self.process.stdout:
            data = json.loads(line)
            ident = data.get('id')
            self.answers[ident] = data
            if ident in self.waiting:
                self.waiting[ident].set()

    def notify(self, method, params):
        with self.lock:
            self.process.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': method, 'params': params}) + '\n')
            self.process.stdin.flush()

    def request(self, method, params):
        with self.lock:
            self.seq += 1
            ident = self.seq
            event = self.waiting[ident] = threading.Event()
            self.process.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': ident, 'method': method, 'params': params}) + '\n')
            self.process.stdin.flush()
        assert event.wait(10), 'MCP callback deadline'
        return self.answers[ident]


def execute(packet):
    global native_id, mcp, params_start
    method, params = packet['method'], packet.get('params', {})
    ident = packet.get('id')
    if method == 'initialize':
        write({'id': ident, 'result': {'protocolVersion': 1, 'agentCapabilities': {'loadSession': True}}})
    elif method in ('thread/start', 'thread/resume', 'session/new', 'session/load'):
        params_start = params
        native_id = params.get('threadId', params.get('sessionId', native_id))
        if protocol == 'grok' and params.get('mcpServers'):
            mcp = MCP(params['mcpServers'][-1])
        result = {'thread': {'id': native_id}, 'model': 'observed-codex'} if protocol == 'codex' else {'sessionId': native_id, 'model': 'observed-grok'}
        write({'id': ident, 'result': result})
    elif method in ('turn/start', 'session/prompt', '_x.ai/interject'):
        if method == 'turn/start':
            text = params.get('toolOutput', {}).get('output') if params.get('toolOutput') else params['input'][0]['text']
        elif method == '_x.ai/interject':
            text = params['text']
        else:
            text = params['prompt'][0]['text']
        try:
            message = json.loads(text)
        except (ValueError, TypeError):
            message = {'text': text}
        body = message.get('body', message)
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except ValueError:
                body = {'text': body}
        prompt = params.get('_meta', {}).get('promptId') or params.get('interjectionId') or uuid.uuid4().hex
        if method in ('turn/start', '_x.ai/interject'):
            write({'id': ident, 'result': {'accepted': True, 'turn': {'id': prompt}, 'wire': params}})
        if protocol == 'codex':
            write({'method': 'turn/started', 'params': {'threadId': native_id, 'turn': {'id': prompt}}})
        else:
            write({'method': 'session/update', 'params': {'sessionId': native_id, 'promptId': prompt, 'update': {
                'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': 'working'}}}})
        if body.get('action') == 'permission':
            call_id = uuid.uuid4().hex
            event = threading.Event()
            callbacks[call_id] = event
            write({'id': call_id, 'method': 'session/request_permission' if protocol == 'grok' else 'item/commandExecution/requestApproval', 'params': {
                'threadId' if protocol == 'codex' else 'sessionId': native_id,
                'toolCall': {'title': body['tool'], 'toolCallId': call_id}, 'options': [
                    {'kind': 'allow_once', 'optionId': 'yes'}, {'kind': 'reject_once', 'optionId': 'no'}]}})
            assert event.wait(10)
        elif body.get('action') == 'tool':
            call(body.get('name', 'echo'), body.get('arguments', {}), prompt, body.get('observed', True))
        if protocol == 'codex':
            write({'method': 'turn/completed', 'params': {'threadId': native_id, 'turn': {'id': prompt, 'status': 'completed'}}})
        else:
            write({'method': '_x.ai/session/prompt_complete', 'params': {'sessionId': native_id, 'promptId': prompt, 'stopReason': 'end_turn'}})
            if method == 'session/prompt':
                write({'id': ident, 'result': {'stopReason': 'end_turn'}})
    elif method == 'authenticate':
        write({'id': ident, 'result': {}})
    elif ident is not None:
        write({'id': ident, 'error': {'code': -32601, 'message': 'Unsupported method'}})


for line in sys.stdin:
    packet = json.loads(line)
    if 'method' in packet:
        threading.Thread(target=execute, args=(packet,), daemon=True).start()
    elif packet.get('id') in callbacks:
        responses[packet['id']] = packet
        callbacks[packet['id']].set()
if mcp:
    mcp.process.terminate()
    mcp.process.wait(timeout=2)
