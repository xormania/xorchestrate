"""B1/B2/A1/A2 through the active application and composed provider boundary."""
import hashlib
import json
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from uuid import uuid4

import pytest

from xorchestrate.adapters.acceptance import RequiredChecksAcceptance
from xorchestrate.adapters.policies import ConfigurableRouting, RuleGuardrail
from xorchestrate.adapters.storage import MemoryStore, SQLiteStore
from xorchestrate.application import Application
from xorchestrate.composition import build
from xorchestrate.model import Assessment, Capability, Conflict, OrchestrationError

CANDIDATE = {"identity": "tree:measured-product", "configuration": "config:nondefault"}
BINDINGS = {"scope": "product", "artifact": {"name": "result.json", "sha256": "measured-artifact"},
            "native": {"session_id": "conversation", "incarnation": "incarnation-2"}}


class MeasuringProvider:
    """Controlled measurement boundary: actual candidate is independent of request."""
    def __init__(self):
        self.actual_candidate = deepcopy(CANDIDATE)
        self.actual_bindings = deepcopy(BINDINGS)
        self.transform = lambda result: result
        self.calls = []
        self.entered = None
        self.release = None

    def discover(self):
        return [Capability("measure", "Measure the configured product", {"type": "object", "required": ["measurement", "arguments"]})]

    def invoke(self, name, arguments, context):
        self.calls.append(deepcopy(arguments))
        if self.entered:
            self.entered.set()
            assert self.release.wait(5), "test measurement release missing"
        request = arguments["measurement"]
        observed = {key: deepcopy(request[key]) for key in ("work_id", "check_id", "requirements_identity", "requirement_revision")}
        observed.update({"candidate": deepcopy(self.actual_candidate), "bindings": deepcopy(self.actual_bindings),
            "status": "completed", "passed": True, "outcomes": {name: True for name in request["outcomes"]}})
        return self.transform({"measurement": observed})

    def close(self):
        pass


class Evaluator:
    def __init__(self, action=None):
        self.contexts = []
        self.action = action

    def assess(self, question, context):
        self.contexts.append(deepcopy(context))
        if self.action:
            self.action()
        return Assessment("pass", .999, "Favorable assessment is not mechanical evidence")

    def close(self):
        pass


def make_app(store=None, provider=None, policy=None, evaluator=None, guardrail=None):
    return Application(store=store if store is not None else MemoryStore(), providers={"checks": provider or MeasuringProvider()}, sessions={},
        guardrail=guardrail or RuleGuardrail(), routing=ConfigurableRouting(), evaluators={"review": evaluator} if evaluator else {},
        clock=lambda: "2026-10-23T20:00:00Z", identifiers=lambda: uuid4().hex,
        assessment={"triage": "review"} if evaluator else {}, acceptance=policy if policy is not None else RequiredChecksAcceptance())


@pytest.fixture(params=["memory", "sqlite"])
def app(request, tmp_path):
    store = MemoryStore() if request.param == "memory" else SQLiteStore(str(tmp_path / "acceptance.sqlite"))
    instance = make_app(store=store)
    yield instance
    store.close()


def setup_work(app, outcomes=None):
    work = app.call("create_work", {"goal": "Deliver A and B"})["work"]
    outcomes = {"A": "Happy path", "B": "Recovery"} if outcomes is None else outcomes
    requirements = app.call("set_requirements", {"work_id": work["id"], "expected_revision": 0,
        "objective": "Deliver the complete owner objective", "outcomes": outcomes,
        "checks": {key: {"capability": "checks/measure", "outcomes": [key], "bindings": BINDINGS} for key in outcomes}})["requirements"]
    app.call("set_candidate", {"work_id": work["id"], "expected_revision": 0, "candidate": CANDIDATE})
    return work, requirements


def measure(app, work, check="A", key=None):
    return app.call("run_measurement", {"work_id": work["id"], "check_id": check, "measurement_key": key or uuid4().hex})


def accept(app, work, assessment=None):
    args = {"work_id": work["id"]}
    if assessment:
        args["assessment_id"] = assessment["id"]
    return app.call("accept_work", args)["acceptance"]


def issues(decision):
    return {item["code"] for item in decision["issues"]}


def test_full_owner_objective_survives_narrowing_and_cancellation(app):
    work, basis = setup_work(app)
    child = app.call("create_contribution", {"work_id": work["id"], "goal": "Implement A and B", "outcomes": ["A", "B"]})["contribution"]
    app.call("update_contribution", {"work_id": work["id"], "contribution_id": child["id"], "expected_version": child["version"],
        "changes": {"goal": "Only A", "outcomes": ["A"], "status": "cancelled"}})
    app.call("update_work", {"work_id": work["id"], "expected_version": work["version"], "changes": {"goal": "Narrowed plan", "status": "done"}})
    measure(app, work, "A")
    decision = accept(app, work)
    assert decision["accepted"] is False, "OWNER_OUTCOME_B_MUST_REMAIN_REQUIRED"
    assert decision["coverage"]["B"]["covered"] is False
    view = app.call("get_work", {"work_id": work["id"]})
    assert view["requirements"]["objective"] == basis["objective"]
    assert set(view["requirements"]["outcomes"]) == {"A", "B"}
    assert view["accepted"] is False
    assert view["contributions"][0]["status"] == "cancelled"


def test_explicit_owner_revision_changes_current_basis_without_erasing_history(app):
    work, basis = setup_work(app)
    measure(app, work, "A")
    assert not accept(app, work)["accepted"]
    revised = app.call("set_requirements", {"work_id": work["id"], "expected_revision": 1, "objective": "Owner now requires A",
        "outcomes": {"A": "Happy path"}, "checks": {"A": basis["checks"]["A"]}})["requirements"]
    assert revised["version"] == 2
    assert "measurement_stale" in issues(accept(app, work))
    measure(app, work)
    assert accept(app, work)["accepted"]
    view = app.call("get_acceptance", {"work_id": work["id"]})
    assert view["accepted"]
    assert any(not item["current"] for item in view["acceptance_history"])
    with app.store.transaction() as tx:
        assert len(tx.list("requirement_revision")) == 2


def test_claim_and_done_status_do_not_create_acceptance(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    app.call("record_result", {"work_id": work["id"], "result": {"passed": True, "candidate": CANDIDATE, "all_required": "done"}})
    decision = accept(app, work)
    assert not decision["accepted"], "CLAIMS_ARE_NOT_MEASUREMENTS"
    assert "measurement_missing" in issues(decision)
    with pytest.raises(OrchestrationError):
        app.call("run_measurement", {"work_id": work["id"], "check_id": "A", "measurement_key": "fake", "result": {"passed": True}})


@pytest.mark.parametrize("mutator,diagnostic", [
    (lambda m: m.update(passed=False), "required_check_failed"),
    (lambda m: m.update(passed=1), "required_check_failed"),
    (lambda m: m.update(status="running"), "measurement_incomplete"),
    (lambda m: m.update(status="uncertain"), "measurement_incomplete"),
    (lambda m: m.update(candidate={"identity": "other-tree"}), "measurement_binding_mismatch"),
    (lambda m: m.update(work_id="unrelated-work"), "measurement_binding_mismatch"),
    (lambda m: m.update(check_id="unrelated-check"), "measurement_binding_mismatch"),
    (lambda m: m.update(requirements_identity="another-criteria"), "measurement_binding_mismatch"),
    (lambda m: m.update(requirement_revision=True), "measurement_binding_mismatch"),
    (lambda m: m["bindings"].update(scope="unrelated-scope"), "measurement_binding_mismatch"),
    (lambda m: m["bindings"]["artifact"].update(sha256="wrong-artifact"), "measurement_binding_mismatch"),
    (lambda m: m["bindings"]["native"].update(session_id="other-session"), "measurement_binding_mismatch"),
    (lambda m: m["bindings"]["native"].update(incarnation="stale-incarnation"), "measurement_binding_mismatch"),
    (lambda m: m.update(outcomes={"A": False}), "required_outcome_failed"),
    (lambda m: m.update(outcomes={"other": True}), "required_outcome_failed"),
    (lambda m: m.pop("candidate"), "measurement_binding_mismatch"),
])
def test_insufficient_or_misbound_measurement_cannot_pass(app, mutator, diagnostic):
    work, _ = setup_work(app, {"A": "Behavior"})
    def transform(result):
        mutator(result["measurement"])
        return result
    app.providers["checks"].transform = transform
    measure(app, work)
    decision = accept(app, work)
    assert not decision["accepted"], "BOUND_REQUIRED_MEASUREMENT_MUST_PASS"
    assert diagnostic in issues(decision)


def test_required_failure_cannot_be_erased_by_unrelated_success_or_high_assessment(app):
    evaluator = Evaluator()
    app.evaluators["review"] = evaluator
    app.assessment = {"triage": "review"}
    work, _ = setup_work(app)
    app.providers["checks"].transform = lambda result: {"measurement": {**result["measurement"], "passed": False}}
    measure(app, work, "B")
    app.providers["checks"].transform = lambda result: result
    measure(app, work, "A")
    assessment = app.call("assess", {"work_id": work["id"], "question": "Is work acceptable?"})["assessment"]
    decision = accept(app, work, assessment)
    assert not decision["accepted"], "FAVORABLE_ASSESSMENT_CANNOT_ERASE_MECHANICAL_FAILURE"
    assert "required_check_failed" in issues(decision)
    assert evaluator.contexts[-1]["acceptance_basis"]["requirements"]["objective"] == "Deliver the complete owner objective"
    measure(app, work, "B")
    assert "assessment_stale" in issues(accept(app, work, assessment))
    assert accept(app, work)["accepted"]


def test_measurement_replay_is_bound_to_request_and_does_not_reexecute(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    first = measure(app, work, key="once")
    second = measure(app, work, key="once")
    assert second["replayed"] and first["measurement"] == second["measurement"]
    assert len(app.providers["checks"].calls) == 1
    with pytest.raises(Conflict):
        app.call("run_measurement", {"work_id": work["id"], "check_id": "A", "measurement_key": "once", "arguments": {"different": True}})


def test_running_measurement_blocks_earlier_pass_and_observation_progresses(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    provider = app.providers["checks"]
    provider.entered, provider.release = threading.Event(), threading.Event()
    with ThreadPoolExecutor() as pool:
        running = pool.submit(measure, app, work)
        assert provider.entered.wait(5)
        try:
            decision = accept(app, work)
            assert not decision["accepted"], "RUNNING_MEASUREMENT_IS_NOT_COMPLETE"
            assert "measurement_unresolved" in issues(decision)
            assert app.call("list_work", {})["work"]
        finally:
            provider.release.set()
        running.result(timeout=5)
    assert accept(app, work)["accepted"]


def test_uncertain_measurement_cannot_be_masked_by_new_pass(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    provider = app.providers["checks"]
    def lost(result):
        raise OrchestrationError("Response lost", "transport_lost", {"outcome": "unknown"})
    provider.transform = lost
    with pytest.raises(OrchestrationError):
        measure(app, work, key="uncertain")
    replay = measure(app, work, key="uncertain")
    assert replay["measurement"]["status"] == "unknown"
    provider.transform = lambda result: result
    measure(app, work)
    decision = accept(app, work)
    assert not decision["accepted"]
    assert "measurement_unresolved" in issues(decision)


@pytest.mark.parametrize("observed_status", ["running", "uncertain"])
def test_incomplete_observed_measurement_cannot_be_hidden_by_later_passing_transport(app, observed_status):
    work, _ = setup_work(app, {"A": "Behavior"})
    provider = app.providers["checks"]
    provider.transform = lambda result: {"measurement": {**result["measurement"], "status": observed_status}}
    measure(app, work)
    provider.transform = lambda result: result
    measure(app, work)
    assert "measurement_unresolved" in issues(accept(app, work)), "UNRESOLVED_MEASUREMENT_CANNOT_BE_MASKED"


def test_caller_reconciliation_cannot_manufacture_measurement_truth(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    provider = app.providers["checks"]
    def lost(result):
        raise OrchestrationError("Lost response", "transport_lost", {"outcome": "unknown"})
    provider.transform = lost
    with pytest.raises(OrchestrationError):
        measure(app, work, key="lost")
    retained = measure(app, work, key="lost")["measurement"]
    operation = app.call("get_operation", {"operation_id": retained["operation_id"]})["operation"]
    fake = {"measurement": {**retained["request_binding"], "status": "completed", "passed": True, "outcomes": {"A": True}}}
    app.call("resolve_operation", {"operation_id": operation["id"], "expected_version": operation["version"],
        "outcome": "completed", "result": fake, "reason": "Caller says it passed"})
    replay = measure(app, work, key="lost")["measurement"]
    assert replay["status"] == "unknown"
    assert not accept(app, work)["accepted"]


def test_observation_must_match_retained_adapter_operation(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    measurement = measure(app, work)["measurement"]
    with app.store.transaction() as tx:
        operation = tx.get("operation", measurement["operation_id"])
        tx.put("operation", operation.key, {**operation.data, "external_result_origin": "caller"}, operation.version)
    assert "measurement_unverified" in issues(accept(app, work)), "ADAPTER_ORIGIN_REQUIRED"


def test_required_outcomes_without_check_remain_uncovered(app):
    work = app.call("create_work", {"goal": "Required capability"})["work"]
    app.call("set_requirements", {"work_id": work["id"], "expected_revision": 0, "objective": "A still required", "outcomes": {"A": "A"}, "checks": {}})
    app.call("set_candidate", {"work_id": work["id"], "expected_revision": 0, "candidate": CANDIDATE})
    decision = accept(app, work)
    assert not decision["accepted"] and "outcome_uncovered" in issues(decision)


def test_duplicate_measurement_json_fields_cannot_supply_a_passing_summary(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    def duplicate(result):
        text = json.dumps(result).replace('"passed": true', '"passed": false, "passed": true')
        return {"content": [{"type": "text", "text": text}]}
    app.providers["checks"].transform = duplicate
    measure(app, work)
    assert "measurement_binding_mismatch" in issues(accept(app, work))


def test_candidate_change_invalidates_existing_acceptance_and_old_evidence(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    assert accept(app, work)["accepted"]
    app.call("set_candidate", {"work_id": work["id"], "expected_revision": 1, "candidate": {"identity": "tree:new"}})
    assert not app.call("get_acceptance", {"work_id": work["id"]})["accepted"], "ACCEPTANCE_MUST_MATCH_CURRENT_CANDIDATE"
    assert "measurement_stale" in issues(accept(app, work))
    measure(app, work)
    assert "measurement_binding_mismatch" in issues(accept(app, work))


def test_same_name_provider_configuration_change_invalidates_measurements_and_decisions(app):
    app.provider_configurations = {"checks": "resolved-checker-config:v1"}
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    assert accept(app, work)["accepted"]
    app.provider_configurations["checks"] = "resolved-checker-config:v2"
    view = app.call("get_acceptance", {"work_id": work["id"]})
    assert not view["accepted"], "ACCEPTANCE_MUST_MATCH_CHECKER_CONFIGURATION"
    assert "measurement_stale" in issues(accept(app, work))
    measure(app, work)
    assert accept(app, work)["accepted"]


def test_unrelated_provider_change_does_not_invalidate_current_measurements(app):
    app.provider_configurations = {"checks": "v1", "unrelated": "v1"}
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    assert accept(app, work)["accepted"]
    app.provider_configurations["unrelated"] = "v2"
    assert app.call("get_acceptance", {"work_id": work["id"]})["accepted"]


def test_later_rejection_does_not_leave_earlier_decision_as_current_acceptance(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    class RevisablePolicy:
        identity = "policy:v1"
        allowed = True
        def evaluate(self, snapshot):
            return {"accepted": self.allowed}
    app.acceptance = RevisablePolicy()
    assert accept(app, work)["accepted"]
    app.acceptance.allowed = False
    assert not accept(app, work)["accepted"]
    assert not app.call("get_acceptance", {"work_id": work["id"]})["accepted"]


def test_requirements_changed_during_assessment_make_it_historical(app):
    work, basis = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    def change():
        app.call("set_requirements", {"work_id": work["id"], "expected_revision": 1, "objective": "Owner revised objective",
            "outcomes": basis["outcomes"], "checks": basis["checks"]})
    evaluator = Evaluator(change)
    app.evaluators["review"], app.assessment = evaluator, {"triage": "review"}
    assessment = app.call("assess", {"work_id": work["id"], "question": "Assess this basis"})["assessment"]
    assert evaluator.contexts[0]["acceptance_basis"]["requirements"]["version"] == 1
    assert "assessment_stale" in issues(accept(app, work, assessment))


def test_changed_basis_during_policy_evaluation_cannot_commit_acceptance(app):
    work, basis = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    class ChangingPolicy:
        identity = "changing-policy-v1"
        def evaluate(self, snapshot):
            app.call("set_requirements", {"work_id": work["id"], "expected_revision": 1, "objective": "Revised while deciding",
                "outcomes": basis["outcomes"], "checks": basis["checks"]})
            return {"accepted": True}
    app.acceptance = ChangingPolicy()
    with pytest.raises(Conflict):
        accept(app, work)
    assert not app.call("get_acceptance", {"work_id": work["id"]})["accepted"]


def test_acceptance_policy_substitutes_without_weakening_required_proof(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    class OtherPolicy:
        identity = "independent-review-required:v1"
        def evaluate(self, snapshot):
            return {"accepted": False, "reasons": [{"code": "deployment_review_pending"}]}
    measure(app, work)
    assert accept(app, work)["accepted"]
    app.acceptance = OtherPolicy()
    assert not app.call("get_acceptance", {"work_id": work["id"]})["accepted"]
    decision = accept(app, work)
    assert not decision["accepted"] and not decision["issues"]
    class OverconfidentPolicy:
        identity = "always-favorable:v1"
        def evaluate(self, snapshot):
            return {"accepted": True}
    app.acceptance = OverconfidentPolicy()
    app.providers["checks"].transform = lambda r: {"measurement": {**r["measurement"], "passed": False}}
    measure(app, work)
    assert not accept(app, work)["accepted"]


def test_required_assessment_policy_and_authorization_remain_independent(app):
    work, _ = setup_work(app, {"A": "Behavior"})
    measure(app, work)
    app.acceptance = RequiredChecksAcceptance({"require_assessment": True})
    assert not accept(app, work)["accepted"]
    app.evaluators["review"], app.assessment = Evaluator(), {"triage": "review"}
    assessment = app.call("assess", {"work_id": work["id"], "question": "Review"})["assessment"]
    assert accept(app, work, assessment)["accepted"]
    app.guardrail = RuleGuardrail({"rules": [{"actions": ["accept_work"], "effect": "deny", "reason": "Owner decision required"}]})
    with pytest.raises(OrchestrationError) as error:
        accept(app, work, assessment)
    assert error.value.code == "denied"


def test_scope_mismatch_and_stale_requirement_revisions_are_rejected(app):
    work, basis = setup_work(app, {"A": "Behavior"})
    other, _ = setup_work(app, {"A": "Other"})
    child = app.call("create_contribution", {"work_id": work["id"], "goal": "A", "outcomes": ["A"]})["contribution"]
    with pytest.raises(OrchestrationError) as error:
        app.call("update_contribution", {"work_id": other["id"], "contribution_id": child["id"], "expected_version": 1, "changes": {"status": "cancelled"}})
    assert error.value.code == "wrong_scope"
    with pytest.raises(Conflict):
        app.call("set_requirements", {"work_id": work["id"], "expected_revision": 0, "objective": "Stale", "outcomes": basis["outcomes"], "checks": basis["checks"]})


def test_composed_cli_measurement_observes_file_identity_instead_of_echoing_request(tmp_path):
    product = tmp_path / "product.txt"
    product.write_text("works\n")
    identity = hashlib.sha256(product.read_bytes()).hexdigest()
    peer = tmp_path / "measure.py"
    peer.write_text('''import hashlib,json,pathlib,sys
request=json.load(sys.stdin)["arguments"]
binding=request["measurement"]
data=pathlib.Path(sys.argv[1]).read_bytes()
actual={key:binding[key] for key in ["work_id","check_id","requirements_identity","requirement_revision"]}
actual.update(candidate={"identity":hashlib.sha256(data).hexdigest()},bindings={},status="completed",passed=data==b"works\\n",outcomes={"A":data==b"works\\n"})
json.dump({"measurement":actual},sys.stdout)
''')
    config = {"store": {"adapter": "sqlite", "options": {"path": "state.sqlite"}},
        "providers": {"checks": {"adapter": "cli", "options": {"command": [sys.executable, str(peer), str(product)],
            "capabilities": [{"name": "measure", "description": "Read actual product", "input_schema": {"type": "object"}}]}}}}
    with build(config, tmp_path) as runtime:
        app = runtime.application
        work = app.call("create_work", {"goal": "Verify product"})["work"]
        app.call("set_requirements", {"work_id": work["id"], "expected_revision": 0, "objective": "File works", "outcomes": {"A": "Works"},
            "checks": {"A": {"capability": "checks/measure", "outcomes": ["A"]}}})
        app.call("set_candidate", {"work_id": work["id"], "expected_revision": 0, "candidate": {"identity": identity}})
        measure(app, work)
        assert accept(app, work)["accepted"]
        product.write_text("broken\n")
        measure(app, work)
        assert "measurement_binding_mismatch" in issues(accept(app, work)), "ACTUAL_PRODUCT_IDENTITY_MUST_BE_MEASURED"
    with build(config, tmp_path) as restarted:
        view = restarted.application.call("get_acceptance", {"work_id": work["id"]})
        assert not view["accepted"]
        assert len(view["measurements"]) == 2


def test_no_requirements_or_acceptance_policy_required_for_simple_messaging():
    with build({"store": {"adapter": "memory"}}) as runtime:
        app = runtime.application
        work = app.call("create_work", {"goal": "Simple messaging"})["work"]
        app.call("add_actor", {"actor_id": "reader"})
        app.call("send_message", {"destination": {"actors": ["reader"]}, "body": "hello", "work_id": work["id"]})
        assert app.call("inbox", {}, actor="reader")["messages"]
        app.acceptance = None
        with pytest.raises(OrchestrationError) as error:
            accept(app, work)
        assert error.value.code == "acceptance_unavailable"
