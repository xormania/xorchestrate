"""Restore exactly one manifest-listed component snapshot from Git plus overlay."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    basis = manifest["basis_commit"]
    resolved = subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", basis + "^{commit}"]).decode().strip()
    if resolved != basis:
        raise ValueError("Basis commit identity mismatch")
    args.out.mkdir(parents=True, exist_ok=False)
    for name, entry in sorted(manifest["files"].items()):
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Unsafe manifest path")
        target = args.out / relative
        for parent in relative.parents:
            if (args.out / parent).is_symlink():
                raise ValueError("Refusing to write through a parent symlink")
        target.parent.mkdir(parents=True, exist_ok=True)
        if entry["content_from"] == "basis":
            data = subprocess.check_output(["git", "-C", str(args.repo), "show", basis + ":" + name])
        else:
            source = args.manifest.parent / "overlay" / relative
            if entry["kind"] == "symlink":
                data = os.readlink(source).encode()
            else:
                if source.is_symlink():
                    raise ValueError("Overlay file unexpectedly became a symlink")
                data = source.read_bytes()
        if hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError("Source hash mismatch: " + name)
        if entry["kind"] == "symlink":
            if data.decode() != entry["target"]:
                raise ValueError("Symlink target mismatch")
            target.symlink_to(entry["target"])
        else:
            target.write_bytes(data)
            target.chmod(int(entry["mode"], 8))
    print(json.dumps({"restored_files": len(manifest["files"]), "basis_commit": basis, "output": str(args.out)}))


if __name__ == "__main__":
    main()
