# Recover pre-freeze component sources

Basis repository: `xormania/xorchestrate`, exact commit `b0a00f1aed08d4ad8e066de8eb51f94e21da9f4a`. These snapshots document component measurements before final integration; they do not receive final acceptance credit.

Each manifest lists the complete included file set for that snapshot, hashes, modes, symlink targets, and content source. Files identical to the basis use Git blobs; only differing files are in `overlay/`. Original candidate manifests, working patches, and component metadata are retained when available. Do not copy an entire final checkout into a component snapshot: that would add files absent from the measured input set.

Run `python3 restore.py --repo /path/to/xorchestrate --manifest NAME/manifest.json --out /empty/new/path` to reconstruct and verify a snapshot. The source repository must have the exact basis commit. Restore excludes `.git`, caches, and bytecode.

`source_hash_cross_checks` reports agreement with original manifests. The older transport `regression-manifest.json` predates the retained `regression-snapshot`; its mismatching hashes are preserved as an explicit limitation. The later `regression-final-manifest.json` matches the retained snapshot.
