"""Run the retained-context exchange/work suite through active composition.

Native mode launches authenticated harnesses only when explicitly invoked by the
operator. Fixture mode uses a declared synthetic session port and never produces
a native pass. Raw records and markers are private run artifacts.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import secrets
import sys
import time
import uuid

from xorchestrate.composition import build, load_config

from .capture import canonical, candidate_identity, digest, file_identity, now, verify_candidate, write_json
from .checker import PEERS, VerificationFailure, check_case, default_criteria, native_inventory, verify
from .normalize import normalize


ROOT = Path(__file__).resolve().parents[2]
FIXTURE = Path(__file__).with_name("build-log.json")


def snapshot(application):
    with application.store.transaction() as tx:
        def records(kind):
            return [{**deepcopy(r.data), "id": r.key, "version": r.version} for r in tx.list(kind)]
        return {"sessions": records("session"), "messages": records("message"), "attempts": records("delivery_attempt"),
                "observations": records("native_observation"), "evidence": records("evidence"),
                "operations": records("operation"), "receipts": records("delivery_receipt")}


def prepare_config(config, base, directory, mode, fixture=FIXTURE):
    config = deepcopy(config)
    for category in ("sessions", "providers"):
        for spec in config.get(category, {}).values():
            if spec.get("options", {}).get("cwd") is not None:
                spec["options"]["cwd"] = str((base / spec["options"]["cwd"]).resolve())
    if mode == "fixture":
        config["sessions"] = {peer: {"adapter": "scripts.verification.fixture:ProtocolFixtureDriver",
            "options": {"peer": peer, "application_tools": True}} for peer in PEERS}
    for peer in PEERS:
        if peer not in config.get("sessions", {}):
            raise ValueError("Configure a session driver named " + peer)
        if config["sessions"][peer].get("options", {}).get("application_tools") is not True:
            raise ValueError("Native application_tools must be enabled for " + peer)
    config["store"] = {"adapter": "sqlite", "options": {"path": str(directory / "state.sqlite3")}}
    config.setdefault("providers", {})["verification"] = {
        "adapter": "scripts.verification.fixture:VerificationProvider", "options": {"fixture": str(fixture), "hold_timeout": 300}}
    # Scheduling is exercised explicitly through the public application action.
    config["delivery_scheduler"] = {"adapter": "manual"}
    return config


class ComposedSuite:
    def __init__(self, runtime, directory, mode, criteria, bindings, fixture, timeout=180):
        self.runtime, self.application = runtime, runtime.application
        self.directory, self.mode, self.timeout = Path(directory), mode, timeout
        self.criteria, self.bindings, self.fixture = criteria, bindings, fixture
        self.provider = self.application.providers["verification"]
        self.run_id = uuid.uuid4().hex
        self.memories = {peer: secrets.token_hex(16) for peer in PEERS}
        self.nonces = {case["id"]: secrets.token_hex(12) for case in criteria["required_cases"]
                       if case["kind"] in {"exchange", "busy", "work_exchange"}}
        self.sessions = {}
        self.executed = []
        self.phase = "setup"
        self.failures = []
        self.lifecycle_events = []
        self.work_id = None
        self.started = now()

    def call(self, action, arguments):
        return self.application.call(action, arguments, actor="owner")

    def raw_run(self):
        raw = snapshot(self.application)
        provider = self.provider.snapshot()
        result = {"mode": self.mode, "run_id": self.run_id, "started_at": self.started, "cutoff": now(),
                  "bindings": self.bindings, "raw_records": raw, "provider_events": provider,
                  "sessions": self.sessions, "memories": self.memories, "nonces": self.nonces,
                  "executed_cases": list(self.executed), "discovered_cases": [c["id"] for c in native_inventory()],
                  "phase": self.phase, "failures": deepcopy(self.failures)}
        result["events"] = normalize(raw, self.sessions, provider, self.mode)
        return result

    def save(self):
        run = self.raw_run()
        write_json(self.directory / "run.json", run)
        write_json(self.directory / "report.json", verify(run, self.criteria, self.bindings, self.fixture))
        return run

    def wait(self, predicate, code):
        deadline = time.monotonic() + self.timeout
        diagnostic = code
        while time.monotonic() < deadline:
            self.call("dispatch_deliveries", {})
            run = self.raw_run()
            try:
                result = predicate(run)
                if result:
                    return result
            except VerificationFailure as exc:
                diagnostic = exc.assertion
            # Callback progress is autonomous; this loop does not call poll_session.
            time.sleep(.025)
        self.save()
        raise VerificationFailure(diagnostic)

    def instruction(self, peer, command, explanation):
        self.call("send_session", {"session_id": self.sessions[peer]["session_id"],
            "message": {"text": explanation + "\nVERIFICATION_COMMAND=" + json.dumps(command, separators=(",", ":"))},
            "idempotency_key": uuid.uuid4().hex})

    def start(self):
        self.work_id = self.call("create_work", {"goal": "Verify persistent three-harness communication and separate work correctness."})["work"]["id"]
        for peer in PEERS:
            self.call("add_actor", {"actor_id": peer})
            session = self.call("start_session", {"driver": peer, "specification": {}, "actor_id": peer,
                                "work_id": self.work_id, "idempotency_key": "startup-" + peer})["session"]
            backend = session["backend"]
            self.sessions[peer] = {"session_id": session["id"], "native_id": backend["native_id"],
                                   "incarnation": backend["incarnation"]}
        for peer in PEERS:
            self.phase = "startup-" + peer
            self.executed.append(self.phase)
            instructions = (
                "You are peer " + peer + " in a persistent communication acceptance run. Keep PRIVATE_MEMORY privately in this conversation. "
                "When a delivered message has body.verification.kind=challenge, call send_message to its sender using destination.actor, "
                "body.verification with the same run_id/case_id/nonce, kind=reply and memory=your PRIVATE_MEMORY. "
                "When it has kind=reply, call record_result with result.verification={run_id,case_id,nonce,memory,phase:'received',peer:message.sender}. "
                "Never echo these messages as prose or only acknowledge an inbox item. Work_id is supplied by the application. "
                "For startup, retain the following memory and call record_result with result.verification={run_id,phase:'ready',memory}. "
                "PRIVATE_MEMORY=" + self.memories[peer] + ". End the turn after that callback.")
            self.instruction(peer, {"kind": "startup", "run_id": self.run_id, "memory": self.memories[peer]}, instructions)
        for peer in PEERS:
            case = next(c for c in self.criteria["required_cases"] if c["id"] == "startup-" + peer)
            self.wait(lambda run, case=case: check_case(case, run, self.fixture), "startup_missing")
        self.settled()

    def settled(self):
        cutoff = now()
        def idle(run):
            for peer in PEERS:
                observed = [e for e in run["events"] if e["peer"] == peer and e["event"] == "activity"]
                if not observed or observed[-1].get("state") != "idle":
                    return False
            return True
        return self.wait(idle, "native_completion_missing")

    def send_case(self, case):
        source, target = case["source"], case["target"]
        payload = {"run_id": self.run_id, "case_id": case["id"], "kind": "challenge",
                   "nonce": self.nonces[case["id"]], "memory": ""}
        self.instruction(source, {"kind": "send", "target": target, "payload": payload},
            "Call send_message exactly once with destination.actor=" + json.dumps(target) + " and body.verification=" + json.dumps(payload) +
            ". End this turn; handle the eventual reply using the retained instructions.")

    def exchange(self, case):
        self.phase = case["id"]
        self.executed.append(case["id"])
        self.settled()
        busy = case["kind"] == "busy"
        if busy:
            self.instruction(case["target"], {"kind": "hold", "case_id": case["id"]},
                'Call invoke with capability="verification/hold", arguments=' + json.dumps({"case_id": case["id"]}) +
                ". The controller releases the hold after native delivery submission.")
            self.wait(lambda run: any(e["event"] == "hold_started" and e.get("case_id") == case["id"]
                                      for e in run["events"]), "outstanding_tool_hold_missing")
        try:
            self.send_case(case)
            if busy:
                def submitted(run):
                    ids = {e["message"]["id"] for e in run["events"] if e["event"] == "queued" and
                           e["message"].get("case_id") == case["id"] and e["message"].get("kind") == "challenge"}
                    return any(e["event"] == "submitted" and e.get("message_id") in ids for e in run["events"])
                self.wait(submitted, "busy_native_submission_missing")
        finally:
            if busy:
                self.provider.release_hold(case["target"], case["id"])
        self.wait(lambda run: check_case(case, run, self.fixture), "exchange_incomplete")
        self.verify_product_receipt(case)

    def verify_product_receipt(self, case):
        messages = snapshot(self.application)["messages"]
        challenge = next(m for m in messages if m.get("body", {}).get("verification", {}).get("case_id") == case["id"]
                         and m["body"]["verification"].get("kind") == "challenge")
        result = self.call("verify_exchange", {"message_id": challenge["id"], "recipient": case["target"],
            "expectation": {"run_id": self.run_id, "case_id": case["id"], "nonce": self.nonces[case["id"]],
                            "memory": self.memories[case["target"]], "sender": case["source"], "recipient": case["target"]}})
        if not result["receipt"]["decision"]["verified"]:
            raise VerificationFailure("active_receipt_policy:" + ",".join(result["receipt"]["decision"]["diagnostics"]))

    def work(self):
        work_exchanges = [c for c in self.criteria["required_cases"] if c["kind"] == "work_exchange"]
        for batch in range(3):
            self.phase = "work-batch-" + str(batch)
            if batch:
                self.provider.release_batch(batch)
            for peer in PEERS:
                self.executed.append(f"work-batch-{peer}-{batch}")
                self.instruction(peer, {"kind": "work", "batch": batch},
                    "Use invoke capability verification/work_next with empty arguments. For each job consider only its highest attempt. "
                    "Report jobs whose latest status is FAIL, and their total failed_tests using verification/work_submit "
                    "arguments {batch,failed_jobs:[sorted IDs],failed_tests:sum}. Do exactly one batch, then end the turn. "
                    "Do not read fixture files. Handle incoming peer messages while later batches remain unfinished.")
            for peer in PEERS:
                case = next(c for c in self.criteria["required_cases"] if c["id"] == f"work-batch-{peer}-{batch}")
                # Communication continues to be measured even if a work answer
                # is wrong; retain correctness as a separate final verdict.
                self.wait(lambda run, peer=peer, batch=batch: any(e["event"] == "work_submitted" and
                          e["peer"] == peer and e["batch"] == batch for e in run["events"]), "work_batch_not_exercised")
            self.settled()
            if batch == 0:
                for case in work_exchanges:
                    self.executed.append(case["id"])
                    self.send_case(case)
                def receipts(run):
                    for case in work_exchanges:
                        expected = {"phase": "received", "case_id": case["id"], "nonce": self.nonces[case["id"]],
                                    "memory": self.memories[case["target"]], "peer": case["target"]}
                        if not any(e["event"] == "report" and e["peer"] == case["source"] and e["report"] == expected for e in run["events"]):
                            return False
                    return True
                self.wait(receipts, "unfinished_work_exchange_receipt_missing")
                self.settled()
        for case in work_exchanges:
            self.wait(lambda run, case=case: check_case(case, run, self.fixture), "unfinished_work_exchange_incomplete")
            self.verify_product_receipt(case)

    def run(self):
        self.start()
        for case in self.criteria["required_cases"]:
            if case["kind"] in {"exchange", "busy"}:
                self.exchange(case)
        self.work()
        self.phase = "completion-and-native-audit"
        for case in self.criteria["required_cases"]:
            if case["kind"] in {"completion", "audit"}:
                self.executed.append(case["id"])
                self.wait(lambda run, case=case: check_case(case, run, self.fixture), "final_native_evidence_missing")
        return self.save()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("fixture", "native"), required=True)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--criteria", type=Path, required=True)
    parser.add_argument("--brief", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--fixture", type=Path, default=FIXTURE)
    parser.add_argument("--timeout", type=float, default=180)
    args = parser.parse_args(argv)
    directory = args.out.resolve()
    if directory == ROOT or ROOT in directory.parents:
        parser.error("Run output must be outside the measured candidate")
    directory.mkdir(parents=True, exist_ok=False, mode=0o700)
    criteria = json.loads(args.criteria.read_text())
    if criteria.get("owner_basis_sha256") != digest(args.brief.read_bytes()):
        parser.error("Criteria are not bound to the selected owner brief")
    fixture = json.loads(args.fixture.read_text())
    config, base = load_config(args.config)
    config = prepare_config(config, base, directory, args.mode, args.fixture.resolve())
    candidate = candidate_identity(ROOT)
    checker_files = {str(p.relative_to(ROOT)): file_identity(p) for p in sorted(Path(__file__).parent.glob("*.py"))}
    bindings = {"candidate_sha256": candidate["content_sha256"], "criteria_sha256": digest(canonical(criteria)),
                "checker_sha256": digest(canonical(checker_files)), "fixture_sha256": digest(canonical(fixture)),
                "configuration_sha256": digest(canonical(config)), "owner_basis_sha256": digest(args.brief.read_bytes())}
    for name, value in (("candidate.json", candidate), ("bindings.json", bindings), ("criteria.json", criteria),
                        ("fixture.json", fixture), ("configuration.json", config), ("checker.json", checker_files)):
        write_json(directory / name, value)
    runtime = None
    suite = None
    try:
        runtime = build(config, base)
        suite = ComposedSuite(runtime, directory, args.mode, criteria, bindings, fixture, args.timeout)
        suite.run()
    except BaseException as exc:
        if suite:
            suite.failures.append({"phase": suite.phase, "type": type(exc).__name__, "diagnostic": str(exc)})
            suite.save()
        else:
            write_json(directory / "setup-failure.json", {"type": type(exc).__name__, "diagnostic": str(exc)})
    finally:
        if runtime:
            # Release owned holds before closing drivers; never strand a native
            # callback behind cleanup of its provider.
            runtime.application.providers["verification"].close()
            runtime.close()
        write_json(directory / "candidate-after.json", verify_candidate(ROOT, candidate))
    report_file = directory / "report.json"
    if not report_file.exists():
        return 1
    report = json.loads(report_file.read_text())
    print(json.dumps({"report": str(report_file), "status": report["status"], "native_acceptance": report["native_acceptance"]}))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
