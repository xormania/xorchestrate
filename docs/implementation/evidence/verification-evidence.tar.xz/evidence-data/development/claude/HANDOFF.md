# Claude native adapter contribution

Base: `30254fd0f184b7e31aa7e0896347429004933ed4` on `repair/behavioral-preservation`.
This contribution is uncommitted; `run.json` binds the measured file contents.
The integrated candidate and fresh-session review remain the lead's responsibility.

## Files

- `xorchestrate/adapters/claude.py`: self-contained native Claude session driver.
- `xorchestrate/adapters/native_gateway.py`: standard-library helper/server for
  private authenticated local MCP and hook traffic, shared with Grok.
- `tests/hexagonal/test_claude_sessions.py`: 14 process-based assertions.
- `tests/hexagonal/fixtures/claude_native.py`: deterministic native-protocol peer.

## Contracts and behavior

`start`, `resume`, `reconnect`, `send`/`deliver`, `poll`, `status`, `detach`, `stop`, `close`,
`bind_application_tools`, and `bind_observer(observer(context, event))` match the
shared session contracts. Backend receipts retain native identity, connection
incarnation, owned-process state, configuration identity and separate requested,
resolved and observed settings. Observer context carries the application session
identity supplied by the application. Callback context additionally carries
native identity, incarnation and the independently observed call ID.

The adapter starts Claude with its channel MCP server and independent native
hooks. Startup requires a matching SessionStart hook, MCP initialization and the
native debug-log channel-registration observation. Channel writes return only a
submission fact. Stop hooks report turn completion separately. PreToolUse native
call identity/tool/arguments must match the MCP application callback before it
executes. Conflicting call-ID reuse and duplicate MCP request replay are guarded.
Native permissions and application authorization are separate. No historical
proof-tool catalog, model choice or tool prohibition is imposed.

The private gateway uses localhost TCP plus a random capability token in a
mode-0600 descriptor within a mode-0700 directory by default. Unix sockets remain
configurable (`gateway_transport: unix`). This environment rejects AF_UNIX socket
creation with errno 1; actual AF_INET loopback IPC works. The first attempted
Unix-backed test run had nine setup failures and supplied no behavioral result.
`environment-probe.json` records the observed environmental distinction.

## Measured verification

`python -m pytest tests/hexagonal/test_claude_sessions.py -q` passed all 14 tests
with no skips. `pytest.log`, `pytest.xml`, and `run.json` retain the command,
time, exit code and input hashes. Ruff and compileall passed the four contributed
files. Tests exercise retained markers, later native callbacks without polling,
channel delivery during a held callback, unrelated-session progress, stale
connections, resume with retained settings, explicit config change, native
allow/deny and mediated calls, missing hook/identity/channel registration,
conflicting calls, duplicate callback replay, and private raw debug retention.

Source calibration is retained at
`/workspace/scratch/13fc354c99cb/evidence-calibration-claude-final`.
Passing control: both selected tests passed. Mutation allowed a callback without
its native hook. The intended test alone failed with
`CLAUDE_NATIVE_HOOK_REQUIRED`; the retained-context control still passed.
Classification: `detected`. The final component calibration was rerun after lifecycle and protocol-fixture changes. Snapshot, exact mutation, commands, raw logs and JUnit
are in that directory. This is component calibration; rebind/rerun against the
final integrated candidate as required by the brief.

## Local native configuration

Configure the `claude` builtin with `command: ["claude"]`, applicable `pass_env`
(e.g. PATH, HOME), and `terminal: inherit`. The user enables the development
channel in that terminal. `startup_timeout` is configurable. `launch` accepts
model, effort, permission_mode, tools, allowed_tools, disallowed_tools,
system_prompt and initial_prompt. Delegated request parameters need an explicit
`request_parameters` schema; trusted launch settings take precedence and the
receipt exposes that precedence. `permissions` maps exact native names (or `*`
and `application_tools`) to allow/deny/ask/defer. Unobserved model/effort remain
null; SessionStart's actual model is retained when supplied by the native hook.

Set `evidence_directory` to a private run directory to retain raw native debug
logs after shutdown. It creates a private incarnation directory. Raw config and
native logs are sensitive and are not automatically published. Without this
option temporary diagnostic files are cleaned up with the owned gateway.

External ownership/attachment uses the separately implemented persistent bridge;
this driver only owns the subprocess it launches. No arbitrary PID attachment
or caller-manufactured native binding is accepted. Resume uses the stored native
identity through the application-authorized adapter receipt.

## Source and limitations

Native mechanism adapted from `xormania/multi-harness-proof` revision
`a944f31b7527807d000da985c546e8b5bc9ff476`: `mhproof/adapters.py` Claude launch,
`mhproof/mcp.py` channel transport, `mhproof/evidence.py` PreToolUse matching,
`mhproof/compat.py` channel readiness. Historical restricted tool policy was not
adopted. Official hooks documentation was inspected:
https://code.claude.com/docs/en/hooks .

No authenticated Claude binary/model run was performed. Vendor channel
availability, installed-version compatibility, actual effective effort and the
full three-harness native scenarios remain pending local measurement. Debug-log
readiness is deliberately version-sensitive: a missing marker fails startup
instead of claiming transport readiness. A hook verifies native tool selection;
the separate MCP callback event verifies the application invocation. Neither is
an acceptance decision or evidence of task correctness by itself.

## Integration review findings

Read-only review of the shared session/Grok adapters reproduced two defects:
Codex accepted a native callback with omitted threadId/callId, and a late
turn/started for an old completed turn overwrote the current pending turn. Both
were reported to the session owner and lead with reproductions. Source review
also identified Grok MCP-request replay scoping, ambiguous identical-call
matching, unbounded interjection retention, generic ACP unknown activity, and
material-versus-operational config identity. The owning agent is repairing these;
the lead's integrated rerun is authoritative for their final status.

The Claude protocol peer now implements startup, send, send_many, hold, work and
lifecycle_probe commands used by the composed suite, plus native-channel
challenge/reply handling. It retains private markers by native UUID, assigns a
unique native fixture prompt ID to each delivery, computes work answers through
actual MCP callbacks, and is explicitly deterministic, never vendor evidence.
