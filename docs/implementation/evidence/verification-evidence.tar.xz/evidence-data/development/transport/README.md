# Transport contribution and internal delivery review

Base: `30254fd0f184b7e31aa7e0896347429004933ed4`. This is component evidence; the lead must rerun the integrated candidate. Native vendor execution and the separate fresh-session review are not claimed here.

## Implementation

- `xorchestrate/adapters/jsonrpc.py`: continuously running response correlation; bounded callback workers, request history, frames, bytes and deadlines; synchronous bounded request writing followed by `request_async()` Future; independent notification observation; replay/conflict checks; unknown outcomes retained on fatal connection failure.
- `xorchestrate/mcp.py`: bounded concurrent application requests with reserved observation/control workers and serialized output; synchronous initialization/framing; malformed calls remain per-request errors.
- `xorchestrate/cli.py`: configurable MCP worker/admission bounds. The uncorrelated `run` protocol remains ordered; use `serve` for concurrent correlated requests.
- `tests/hexagonal/test_transport_progress.py`: real subprocess concurrency, callback, bounds, identity, lifecycle and MCP tests.
- `tests/hexagonal/test_delivery_adversarial.py`: independent adversarial review of the lead's application, delivery and composition changes. Shared application source was repaired by the lead, not this reviewer.

`request_async(method, params, timeout=None)` returns only after the request frame is written. Its Future represents the eventual native RPC response. A completed write is not receipt, turn completion, or task acceptance. Notification observers and Future completion callbacks must be short and nonblocking. Callback handlers may issue further requests on the connection. Callback execution and transport buffers remain bounded; expired effects close the owned process and preserve uncertainty.

## Final component results

The current result and exact source/test/fixture hashes are in `verified-component-manifest.json`; raw output and JUnit are `verified-component.log` and `verified-component.xml`. `verified-snapshot/` preserves every measured input used by these checks. Earlier runs and failed-attempt logs are retained separately; do not substitute them for the final integrated run.

From `verified-snapshot/`, reproduce:

```bash
python -m pytest tests/hexagonal/test_transport_progress.py tests/hexagonal/test_jsonrpc.py tests/hexagonal/test_capabilities.py tests/hexagonal/test_transports.py tests/hexagonal/test_delivery_adversarial.py -q
```

The final calibration has a passing control, then one isolated mutation that drops callback dispatch after an acknowledged submission. `post_ack_callback_progress` must fail while the out-of-order response control remains passing. Inspect `verified-calibration-control.*`, `verified-calibration-fault.*`, and `verified-calibration.patch`. No mutation was planted in shared source. The retained snapshot is restored to its passing input; the patch identifies the exact fault.

## Internal review findings resolved by the lead

1. Authorize the effective fallback driver before launch and again on replay using the retained actual selection.
2. Reject callbacks from stopped, detached, superseded or mismatched sources, including changes during authorization before an effect commits.
3. Preserve closed lifecycle state when an outstanding send later fails or succeeds; a superseded connection cannot be revived.
4. Revalidate selected session eligibility immediately before native delivery reservation.
5. Recheck receipt authorization after policy evaluation.
6. Durably reserve semantic native call identity even for application actions without an ordinary idempotency key; exact replays cannot repeat effects.
7. Reject conflicting native submission identity claims and retain the rejected result for investigation.
8. Reauthorize completed native-call replay under current permissions.
9. Retry only explicitly safe pre-effect context conflicts; post-enqueue dispatch errors cannot repeat the committed message.
10. Bind native-call recovery authorization to the target session/work and require the retained, exact adapter-origin completion. Caller results, wrong incarnations and stale observations cannot manufacture recovery.

These are internal review findings, not a substitute for the requested fresh-session independent review. The adversarial tests preserve their failing assertions where defects were initially reproduced; the lead's integrated run must demonstrate the repaired candidate.

## Expectation and diagnostic changes

`test_transports.py` now expects `invalid_state` for a persisted disconnected session after runtime shutdown. The new lifecycle record rejects a stale send before starting an external operation; the old assertion expected the adapter to reject a stale handle afterward. The invariant remains that no implicit restart or delivery occurs.

One earlier integrated run observed an unexplained nonzero exit in the pre-existing `late_input` process fixture. `run_json_process` was not changed by this contribution. The focused test and 40 repetitions with captured stderr, exact status and fixture markers all passed with exit 0; see `early-stdout-diagnostic.json`. The earlier retained log did not contain its exit code and its temporary marker was no longer available. No root cause or speculative fix is claimed. `test_jsonrpc.py` now reports the exception details and markers if the event recurs. Preserve the original integrated failure record alongside subsequent results.
